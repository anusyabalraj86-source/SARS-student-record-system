const supabaseUrl = "file:///C:/Users/Anusy/Downloads/index5.html";
const supabaseKey = "sb_publishable__EMooHueijBdWm4mkm54cQ_Y9k3GQNq";

const supabase = window.supabase.createClient(
  supabaseUrl,
  supabaseKey
);
const { data, error } = await supabase
  .from("users")
  .select("*");

console.log(data);
console.log(error);