"""
Test script to verify all major REST API endpoints of the SARS Django backend.
"""
import os
import django
import json

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sars_backend.settings')
django.setup()

from rest_framework.test import APIClient

def test_endpoints():
    client = APIClient()
    print("=== Testing SARS Django REST Framework Backend Endpoints ===\n")

    # 1. Test API Root Overview
    res = client.get('/api/')
    assert res.status_code == 200, f"API overview failed: {res.status_code}"
    print("[PASS] 1. API Root Overview: OK (Status 200)")

    # 2. Test Student Login (Aditi Sharma)
    res = client.post('/api/auth/login/student/', {
        'identifier': 'aditi.s@inst.edu',
        'password': 'aditi@123'
    }, format='json')
    assert res.status_code == 200 and res.data['success'], f"Student login failed: {res.data}"
    print(f"[PASS] 2. Student Login: OK (Welcome {res.data['student']['name']}, Role: {res.data['role']})")

    # 3. Test Faculty Login (HOD Dr. K. Ramesh)
    res = client.post('/api/auth/login/faculty/', {
        'email': 'hod.cse@institution.edu',
        'password': 'faculty@123'
    }, format='json')
    assert res.status_code == 200 and res.data['success'], f"Faculty login failed: {res.data}"
    print(f"[PASS] 3. Faculty Login: OK (Role: {res.data['faculty_role']}, Name: {res.data['faculty']['name']})")

    # 4. Test Student Profile
    res = client.get('/api/profile/student/?student_id=S1')
    assert res.status_code == 200 and res.data['reg_no'] == '21CSE045', f"Profile get failed: {res.data}"
    print(f"[PASS] 4. Student Profile: OK (Reg No: {res.data['reg_no']}, Dept: {res.data['department']}, Year: {res.data['year']})")

    # 5. Test SGPA and CGPA Calculation
    res = client.get('/api/academics/sgpa-cgpa/?student_id=S1')
    assert res.status_code == 200, f"SGPA/CGPA failed: {res.data}"
    print(f"[PASS] 5. SGPA & CGPA: OK (CGPA: {res.data['cgpa']}, Earned Credits: {res.data['total_credits']}, Semesters: {len(res.data['semesters'])})")

    # 6. Test Attendance
    res = client.get('/api/attendance/student/?student_id=S1')
    assert res.status_code == 200, f"Attendance failed: {res.data}"
    print(f"[PASS] 6. Attendance: OK (Total: {res.data['total_working_days']} days, Attendance %: {res.data['attendance_percentage']}%)")

    # 7. Test Homework
    res = client.get('/api/homework/student/?student_id=S1')
    assert res.status_code == 200 and len(res.data) >= 2, f"Homework failed: {res.data}"
    print(f"[PASS] 7. Homework: OK (Total Homework items: {len(res.data)})")

    # 8. Test LMS Courses & Materials
    res = client.get('/api/lms/courses/?dept=CSE')
    assert res.status_code == 200 and len(res.data) >= 2, f"LMS Courses failed: {res.data}"
    print(f"[PASS] 8. LMS Courses: OK (Courses found: {len(res.data)})")

    # 9. Test Activities Overview
    res = client.get('/api/activities/student/?student_id=S1')
    assert res.status_code == 200, f"Activities failed: {res.data}"
    print(f"[PASS] 9. Activities & Portfolio: OK (Skills: {res.data['skills']}, Projects: {len(res.data['projects'])})")

    # 10. Test Notifications
    res = client.get('/api/notifications/')
    assert res.status_code == 200 and len(res.data) >= 2, f"Notifications failed: {res.data}"
    print(f"[PASS] 10. Notifications: OK (Active notices: {len(res.data)})")

    # 11. Test Faculty Student Directory (HOD view)
    res = client.get('/api/faculty/students/?faculty_email=hod.cse@institution.edu')
    assert res.status_code == 200 and len(res.data) >= 1, f"Faculty students directory failed: {res.data}"
    print(f"[PASS] 11. Faculty Student Directory: OK (Accessible students: {len(res.data)})")

    # 12. Test Faculty Analytics
    res = client.get('/api/faculty/analytics/?faculty_email=hod.cse@institution.edu&dept=CSE')
    assert res.status_code == 200, f"Faculty analytics failed: {res.data}"
    print(f"[PASS] 12. Faculty Analytics: OK (Total Students: {res.data['total_students']}, Avg Attendance: {res.data['average_attendance']}%, Avg Placement Score: {res.data['average_placement_score']})")

    # 13. Test Daily Class Log
    res = client.get('/api/academics/daily-log/?dept=CSE')
    assert res.status_code == 200, f"Daily class log failed: {res.data}"
    print(f"[PASS] 13. Daily Class Log: OK (Logs found: {len(res.data)})")

    # 14. Test Student Registration with Password Hashing
    test_reg_email = "vikram.k@inst.edu"
    test_reg_no = "21CSE099"
    res = client.post('/api/auth/register/', {
        'name': 'Vikram Kumar',
        'reg_no': test_reg_no,
        'department': 'CSE',
        'year': '3rd Year',
        'section': 'B',
        'email': test_reg_email,
        'password': 'vikrampassword123',
        'confirm_password': 'vikrampassword123',
        'phone': '9840011223'
    }, format='json')
    assert res.status_code == 201, f"Registration failed: {res.data}"
    print(f"[PASS] 14. Student Registration: OK (Registered {test_reg_no} with PBKDF2 hashed password)")

    # 15. Verify Password Hashing in Database
    from accounts.models import User as SARSUser
    new_user = SARSUser.objects.get(email=test_reg_email)
    assert new_user.password.startswith('pbkdf2_sha256$'), "Password is NOT securely hashed!"
    print(f"[PASS] 15. Password Security: OK (Algorithm: {new_user.password.split('$')[0]})")

    print("\nALL 15 VERIFICATION TESTS PASSED SUCCESSFULLY! 100% FUNCTIONAL.")

if __name__ == '__main__':
    test_endpoints()
