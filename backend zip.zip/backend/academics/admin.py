from django.contrib import admin
from .models import Subject, SubjectMark, DailyClassLog, DailyLogMessage

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'department', 'semester', 'credits', 'faculty_name')
    search_fields = ('code', 'name')
    list_filter = ('department', 'semester')


@admin.register(SubjectMark)
class SubjectMarkAdmin(admin.ModelAdmin):
    list_display = ('student', 'subject', 'semester', 'i1', 'i2', 'i3', 'model_exam', 'grade', 'is_arrear')
    search_fields = ('student__name', 'student__reg_no', 'subject__code', 'subject__name')
    list_filter = ('semester', 'grade', 'is_arrear')


class DailyLogMessageInline(admin.TabularInline):
    model = DailyLogMessage
    extra = 0


@admin.register(DailyClassLog)
class DailyClassLogAdmin(admin.ModelAdmin):
    list_display = ('date', 'course_code', 'topic', 'department', 'faculty_name')
    search_fields = ('course_code', 'topic', 'faculty_name')
    list_filter = ('department', 'date')
    inlines = [DailyLogMessageInline]
