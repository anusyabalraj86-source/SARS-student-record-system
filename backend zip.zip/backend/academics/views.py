from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

from accounts.models import StudentProfile
from .models import Subject, SubjectMark, DailyClassLog, DailyLogMessage
from .serializers import SubjectSerializer, SubjectMarkSerializer, DailyClassLogSerializer, DailyLogMessageSerializer

class StudentMarksView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')
        semester = request.query_params.get('semester')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        marks_qs = SubjectMark.objects.filter(student=student)
        if semester:
            marks_qs = marks_qs.filter(semester=semester)

        # Group by semester for easy rendering in student.html
        semesters_data = {}
        for mark in marks_qs.select_related('subject').order_by('semester', 'subject__code'):
            sem = mark.semester
            if sem not in semesters_data:
                semesters_data[sem] = {
                    'sem': sem,
                    'subjects': []
                }
            semesters_data[sem]['subjects'].append({
                'id': mark.subject.code,
                'name': mark.subject.name,
                'credits': mark.subject.credits,
                'grade': mark.grade,
                'grade_point': mark.grade_point,
                'i1': mark.i1,
                'i2': mark.i2,
                'i3': mark.i3,
                'model': mark.model_exam,
                'mark_id': mark.id,
                'is_arrear': mark.is_arrear
            })

        return Response({
            'student_id': student.student_id,
            'reg_no': student.reg_no,
            'name': student.name,
            'semesters': list(semesters_data.values())
        }, status=status.HTTP_200_OK)


class SaveMarksView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        student_id = request.data.get('student_id')
        reg_no = request.data.get('reg_no')
        subject_code = request.data.get('subject_code') or request.data.get('subject_id')
        semester = request.data.get('semester', 1)
        i1 = float(request.data.get('i1', 0))
        i2 = float(request.data.get('i2', 0))
        i3 = float(request.data.get('i3', 0))
        model_exam = float(request.data.get('model', request.data.get('model_exam', 0)))
        grade = request.data.get('grade', 'A')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        subject = Subject.objects.filter(code__iexact=subject_code).first()
        if not subject:
            # Auto create subject if not found
            subject_name = request.data.get('subject_name', subject_code)
            credits = int(request.data.get('credits', 3))
            subject = Subject.objects.create(
                code=subject_code,
                name=subject_name,
                department=student.department,
                semester=int(semester),
                credits=credits
            )

        mark, created = SubjectMark.objects.update_or_create(
            student=student,
            subject=subject,
            defaults={
                'semester': int(semester),
                'i1': i1,
                'i2': i2,
                'i3': i3,
                'model_exam': model_exam,
                'grade': grade,
                'is_arrear': (grade == 'F')
            }
        )

        return Response({
            'success': True,
            'message': 'Marks updated successfully.',
            'mark': SubjectMarkSerializer(mark).data
        }, status=status.HTTP_200_OK)


class SubjectManagementView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        dept = request.query_params.get('department')
        sem = request.query_params.get('semester')
        qs = Subject.objects.all()
        if dept:
            qs = qs.filter(department__iexact=dept)
        if sem:
            qs = qs.filter(semester=sem)
        return Response(SubjectSerializer(qs, many=True).data)

    def post(self, request):
        serializer = SubjectSerializer(data=request.data)
        if serializer.is_valid():
            subject = serializer.save()
            return Response({'success': True, 'subject': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk=None):
        try:
            subject = Subject.objects.get(pk=pk)
            subject.delete()
            return Response({'success': True, 'message': 'Subject deleted.'}, status=status.HTTP_200_OK)
        except Subject.DoesNotExist:
            return Response({'error': 'Subject not found.'}, status=status.HTTP_404_NOT_FOUND)


class SGPACGPAView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        marks = SubjectMark.objects.filter(student=student).select_related('subject')

        # Group by semester
        semesters_calc = {}
        for m in marks:
            sem = m.semester
            if sem not in semesters_calc:
                semesters_calc[sem] = {
                    'semester': sem,
                    'total_credits': 0,
                    'weighted_points': 0,
                    'subjects_count': 0,
                    'arrears_count': 0,
                    'subjects': []
                }
            creds = m.subject.credits
            gp = m.grade_point
            semesters_calc[sem]['total_credits'] += creds
            semesters_calc[sem]['weighted_points'] += (creds * gp)
            semesters_calc[sem]['subjects_count'] += 1
            if m.grade == 'F':
                semesters_calc[sem]['arrears_count'] += 1
            
            semesters_calc[sem]['subjects'].append({
                'code': m.subject.code,
                'name': m.subject.name,
                'credits': creds,
                'grade': m.grade,
                'grade_point': gp
            })

        semesters_summary = []
        cumulative_credits = 0
        cumulative_points = 0
        total_arrears = 0
        arrear_subjects = []

        for sem in sorted(semesters_calc.keys()):
            data = semesters_calc[sem]
            c = data['total_credits']
            w = data['weighted_points']
            sgpa = round(w / c, 2) if c > 0 else 0.0
            data['sgpa'] = sgpa
            semesters_summary.append({
                'semester': sem,
                'credits': c,
                'sgpa': sgpa,
                'arrears_count': data['arrears_count']
            })
            cumulative_credits += c
            cumulative_points += w
            total_arrears += data['arrears_count']

        cgpa = round(cumulative_points / cumulative_credits, 2) if cumulative_credits > 0 else 0.0

        for m in marks:
            if m.grade == 'F':
                arrear_subjects.append({
                    'code': m.subject.code,
                    'name': m.subject.name,
                    'semester': m.semester
                })

        return Response({
            'student_id': student.student_id,
            'reg_no': student.reg_no,
            'name': student.name,
            'semesters': semesters_summary,
            'cgpa': cgpa,
            'total_credits': cumulative_credits,
            'standing_arrears': total_arrears,
            'arrear_subjects': arrear_subjects
        }, status=status.HTTP_200_OK)


class DailyClassLogView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        dept = request.query_params.get('dept') or request.query_params.get('department')
        course = request.query_params.get('course')
        date = request.query_params.get('date')

        qs = DailyClassLog.objects.all()
        if dept:
            qs = qs.filter(department__iexact=dept)
        if course:
            qs = qs.filter(course_code__iexact=course)
        if date:
            qs = qs.filter(date=date)

        serializer = DailyClassLogSerializer(qs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = DailyClassLogSerializer(data=request.data)
        if serializer.is_valid():
            log = serializer.save()
            return Response({'success': True, 'log': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class DailyLogMessageView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, log_id):
        try:
            log = DailyClassLog.objects.get(pk=log_id)
        except DailyClassLog.DoesNotExist:
            return Response({'error': 'Daily log entry not found.'}, status=status.HTTP_404_NOT_FOUND)

        sender_name = request.data.get('sender_name', 'Student')
        sender_role = request.data.get('sender_role', 'student')
        message = request.data.get('message', '').strip()

        if not message:
            return Response({'error': 'Message cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)

        msg = DailyLogMessage.objects.create(
            log=log,
            sender_name=sender_name,
            sender_role=sender_role,
            message=message
        )
        return Response({'success': True, 'message': DailyLogMessageSerializer(msg).data}, status=status.HTTP_201_CREATED)
