from django.db import models
from accounts.models import StudentProfile

class Subject(models.Model):
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=150)
    department = models.CharField(max_length=50, default='CSE')
    semester = models.IntegerField(default=1)
    credits = models.IntegerField(default=3)
    faculty_name = models.CharField(max_length=150, blank=True)

    def __str__(self):
        return f"{self.code} - {self.name} (Sem {self.semester})"


class SubjectMark(models.Model):
    GRADE_CHOICES = [
        ('O', 'O (Outstanding)'),
        ('A+', 'A+ (Excellent)'),
        ('A', 'A (Very Good)'),
        ('B+', 'B+ (Good)'),
        ('B', 'B (Average)'),
        ('C', 'C (Satisfactory)'),
        ('P', 'P (Pass)'),
        ('F', 'F (Fail / Arrear)'),
    ]

    GRADE_POINTS = {
        'O': 10,
        'A+': 9,
        'A': 8,
        'B+': 7,
        'B': 6,
        'C': 5,
        'P': 4,
        'F': 0,
    }

    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='marks')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='marks')
    semester = models.IntegerField(default=1)
    i1 = models.FloatField(default=0.0, verbose_name="Internal 1")
    i2 = models.FloatField(default=0.0, verbose_name="Internal 2")
    i3 = models.FloatField(default=0.0, verbose_name="Internal 3")
    model_exam = models.FloatField(default=0.0, verbose_name="Model Exam")
    grade = models.CharField(max_length=5, choices=GRADE_CHOICES, default='A')
    is_arrear = models.BooleanField(default=False)

    class Meta:
        unique_together = ('student', 'subject')

    def save(self, *args, **kwargs):
        if self.grade == 'F':
            self.is_arrear = True
        else:
            self.is_arrear = False
        super().save(*args, **kwargs)

    @property
    def grade_point(self):
        return self.GRADE_POINTS.get(self.grade, 0)

    @property
    def total_internal(self):
        return round((self.i1 + self.i2 + self.i3) / 3, 2)

    def __str__(self):
        return f"{self.student.name} - {self.subject.code}: {self.grade}"


class DailyClassLog(models.Model):
    date = models.DateField()
    course_code = models.CharField(max_length=30)
    course_title = models.CharField(max_length=150, blank=True)
    department = models.CharField(max_length=50, default='CSE')
    section = models.CharField(max_length=10, blank=True, default='A')
    topic = models.CharField(max_length=255)
    faculty_name = models.CharField(max_length=150)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-id']

    def __str__(self):
        return f"{self.date} - {self.course_code}: {self.topic}"


class DailyLogMessage(models.Model):
    log = models.ForeignKey(DailyClassLog, on_delete=models.CASCADE, related_name='messages')
    sender_name = models.CharField(max_length=150)
    sender_role = models.CharField(max_length=30, default='student')
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender_name}: {self.message[:30]}"
