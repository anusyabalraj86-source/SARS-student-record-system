from rest_framework import serializers
from .models import Subject, SubjectMark, DailyClassLog, DailyLogMessage

class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = '__all__'


class SubjectMarkSerializer(serializers.ModelSerializer):
    subject_code = serializers.CharField(source='subject.code', read_only=True)
    subject_name = serializers.CharField(source='subject.name', read_only=True)
    credits = serializers.IntegerField(source='subject.credits', read_only=True)
    grade_point = serializers.IntegerField(read_only=True)

    class Meta:
        model = SubjectMark
        fields = [
            'id', 'student', 'subject', 'subject_code', 'subject_name',
            'semester', 'credits', 'i1', 'i2', 'i3', 'model_exam',
            'grade', 'grade_point', 'is_arrear'
        ]


class DailyLogMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailyLogMessage
        fields = '__all__'


class DailyClassLogSerializer(serializers.ModelSerializer):
    messages = DailyLogMessageSerializer(many=True, read_only=True)

    class Meta:
        model = DailyClassLog
        fields = '__all__'
