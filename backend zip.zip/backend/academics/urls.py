from django.urls import path
from .views import (
    StudentMarksView,
    SaveMarksView,
    SubjectManagementView,
    SGPACGPAView,
    DailyClassLogView,
    DailyLogMessageView
)

urlpatterns = [
    # Marks
    path('marks/student/', StudentMarksView.as_view(), name='student-marks'),
    path('marks/save/', SaveMarksView.as_view(), name='save-marks'),
    path('marks/subject/add/', SubjectManagementView.as_view(), name='add-subject'),
    path('marks/subject/<int:pk>/', SubjectManagementView.as_view(), name='delete-subject'),
    path('marks/subjects/', SubjectManagementView.as_view(), name='list-subjects'),

    # SGPA & CGPA
    path('academics/sgpa-cgpa/', SGPACGPAView.as_view(), name='sgpa-cgpa'),

    # Daily Class Log
    path('academics/daily-log/', DailyClassLogView.as_view(), name='daily-log-list-create'),
    path('academics/daily-log/<int:log_id>/message/', DailyLogMessageView.as_view(), name='daily-log-message'),
]
