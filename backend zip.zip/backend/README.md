# Student Activity Record System (SARS) — Django REST Framework Backend

A modular, secure RESTful backend built with **Python**, **Django 6.1**, and **Django REST Framework (DRF)** with an **SQLite** database, specifically tailored to support all features and data structures of the SARS frontend (`student.html`).

---

## 📁 Directory Structure

```text
backend/
├── manage.py                   # Django management script
├── requirements.txt            # Python package dependencies
├── seed_data.py                # Database seeder populating demo student, faculty & coursework
├── test_apis.py                # Automated test script testing all 19 modules
├── README.md                   # Complete backend documentation
├── db.sqlite3                  # SQLite database
├── media/                      # Upload directory (photos, documents, learning materials)
│   ├── profiles/
│   ├── documents/
│   └── materials/
├── sars_backend/               # Core Django project configuration
│   ├── __init__.py
│   ├── settings.py             # Configured with CORS, Auth, DRF, Media, and modular apps
│   ├── urls.py                 # Central URL router with /api/ overview endpoint
│   ├── wsgi.py
│   └── asgi.py
├── accounts/                   # [Modules 1, 2, 3, 4] Registration, Logins, Profile, Auth
│   ├── models.py               # User (custom model), StudentProfile, FacultyProfile
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── migrations/
├── academics/                  # [Modules 7, 8, 12] Marks, SGPA/CGPA, Daily Class Log
│   ├── models.py               # Subject, SubjectMark, DailyClassLog, DailyLogMessage
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── migrations/
├── attendance/                 # [Module 5] Attendance & Absentee Parent Alerts
│   ├── models.py               # AttendanceRecord, ParentAlert
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── migrations/
├── lms/                        # [Modules 6, 13, 14] LMS Courses, Materials, Homework
│   ├── models.py               # LMSCourse, LearningMaterial, Homework, HomeworkSubmission
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── migrations/
├── activities/                 # [Modules 9, 10] Co/Extra-curricular, Portfolio, Faculty Tasks
│   ├── models.py               # Sports, Cultural, Hackathons, Internships, Skills, Projects
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── migrations/
├── communication/              # [Modules 11, 19] Circular Notices & Direct Messaging
│   ├── models.py               # Notification, NotificationReply, DirectMessage
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── migrations/
├── documents/                  # [Module 15] Student Marksheets & Certificate Uploads
│   ├── models.py               # StudentDocument
│   ├── serializers.py
│   ├── views.py
│   ├── urls.py
│   ├── admin.py
│   └── migrations/
└── faculty_portal/             # [Modules 16, 17, 18] Directory, Scoped Records, Analytics, Reports
    ├── serializers.py
    ├── views.py
    ├── urls.py
    ├── admin.py
    └── migrations/
```

---

## ⚙️ Installation & Commands

### Where to run commands:
Open your terminal (Command Prompt or PowerShell) and navigate into the `backend/` directory:
```bash
cd "c:\Users\Anusy\Desktop\NIT clg\backend"
```

### Step 1: Install Dependencies
```bash
python -m pip install -r requirements.txt
```

### Step 2: Apply Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 3: Populate Database with Seed Data (Demo Students & Faculty)
```bash
python seed_data.py
```

### Step 4: Run Automated Verification Tests
```bash
python test_apis.py
```

### Step 5: Start the Django Development Server
```bash
python manage.py runserver
```

---

## 🌐 URLs & Access Points

| Service | Local URL | Description |
| :--- | :--- | :--- |
| **API Root Overview** | `http://127.0.0.1:8000/` or `http://127.0.0.1:8000/api/` | Interactive JSON overview listing all endpoints and operational status |
| **Django Admin Panel** | `http://127.0.0.1:8000/admin/` | Visual administration dashboard to manage all records |
| **Media Files** | `http://127.0.0.1:8000/media/` | Direct access to uploaded documents and profile pictures |

---

## 🔑 Pre-seeded Demo Credentials

All accounts use secure **PBKDF2-SHA256** password hashing.

### 1. Django Admin / Superuser
- **Email / Username**: `admin@institution.edu` or `admin`
- **Password**: `adminpassword123`
- **Role**: System Administrator (Full Access)

### 2. Faculty Accounts
| Name | Role | Email | Password | Access Scope |
| :--- | :--- | :--- | :--- | :--- |
| **Dr. K. Ramesh** | HOD | `hod.cse@institution.edu` | `faculty@123` | Entire CSE department (all sections) |
| **Prof. M. Devi** | Class Advisor | `advisor.cse.a@institution.edu` | `faculty@123` | CSE - Section A only |
| **Prof. J. Kumar** | Class Advisor | `advisor.cse.b@institution.edu` | `faculty@123` | CSE - Section B only |
| **Prof. S. Latha** | Faculty (Handler) | `staff.cse@institution.edu` | `faculty@123` | CSE - Sections A & B (DBMS) |

### 3. Student Account
- **Name**: Aditi Sharma
- **Register Number**: `21CSE045`
- **Email**: `aditi.s@inst.edu`
- **Password**: `aditi@123`
- **Department**: CSE | 3rd Year | Section A

---

## 📡 Complete REST API Endpoint Reference

### 1. Authentication & Security
- `POST /api/auth/register/` — Register new student with PBKDF2 password hashing
- `POST /api/auth/login/student/` — Login with Email or Register No + Password
- `POST /api/auth/login/faculty/` — Login with Faculty Email + Password
- `POST /api/auth/change-password/` — Change user password securely

### 2. Student Profile
- `GET /api/profile/student/?student_id=S1` — Get complete student profile
- `PUT /api/profile/student/` — Update profile contact, address, or details
- `POST /api/profile/student/photo/` — Upload profile photo

### 3. Attendance & Parent Alerts
- `GET /api/attendance/student/?student_id=S1` — Student attendance %, present/absent count, dates
- `POST /api/attendance/mark/` — Faculty single/bulk attendance marking
- `GET /api/attendance/parent-alerts/?dept=CSE` — Log of SMS/notification alerts sent to parents
- `POST /api/attendance/parent-alert/send/` — Send/record alert to parent for absent student

### 4. Academics, Marks & SGPA/CGPA
- `GET /api/marks/student/?student_id=S1` — Semester-wise subject marks (Internals 1, 2, 3, Model, Grade)
- `POST /api/marks/save/` — Faculty save/update student marks
- `GET /api/marks/subjects/?department=CSE` — List department subjects
- `GET /api/academics/sgpa-cgpa/?student_id=S1` — Calculated SGPA per semester, overall CGPA, earned credits, arrears
- `GET /api/academics/daily-log/?dept=CSE` — Daily lecture topic log
- `POST /api/academics/daily-log/add/` — Faculty add daily class log
- `POST /api/academics/daily-log/<id>/message/` — Ask question / discussion on lecture topic

### 5. LMS & Homework
- `GET /api/lms/courses/?dept=CSE` — LMS courses with learning materials
- `POST /api/lms/courses/` — Create new course
- `GET /api/lms/materials/?course_id=1` — Materials list (PDF, PPT, books)
- `POST /api/lms/materials/upload/` — Upload learning material file
- `GET /api/homework/student/?student_id=S1` — Homework with student completion status
- `POST /api/homework/create/` — Faculty post assignment
- `POST /api/homework/<id>/toggle/` — Student toggle homework done/pending
- `POST /api/homework/<id>/message/` — Homework discussion thread

### 6. Activities & Portfolio
- `GET /api/activities/student/?student_id=S1` — Student activities overview (sports, internships, hackathons, skills, projects)
- `POST /api/activities/faculty/assignments/` — Faculty assigns activity
- `POST /api/activities/assignments/<id>/toggle/` — Student toggle activity completed
- `POST /api/activities/internships/` — Add internship
- `POST /api/activities/sports/` — Add sport achievement
- `POST /api/activities/cultural/` — Add cultural achievement
- `POST /api/activities/hackathons/` — Add hackathon achievement
- `POST /api/activities/workshops/` — Add workshop attended
- `POST /api/activities/papers/` — Add paper presentation
- `POST /api/portfolio/skills/` — Add portfolio skill
- `POST /api/portfolio/projects/` — Add project
- `POST /api/portfolio/certifications/` — Add certification

### 7. Notifications & Communication
- `GET /api/notifications/?dept=CSE` — Circular notices with reply threads
- `POST /api/notifications/create/` — Post official notification
- `POST /api/notifications/<id>/reply/` — Reply to notification
- `GET /api/communication/messages/?email=...` — Student-Faculty direct communication inbox
- `POST /api/communication/messages/` — Send message / doubt
- `PATCH /api/communication/messages/<id>/read/` — Mark message as read

### 8. Document Uploads
- `POST /api/documents/upload/` — Upload marksheets, Aadhar, APAAR, certificates
- `GET /api/documents/my-documents/?student_id=S1` — Retrieve student uploaded documents
- `PATCH /api/documents/<id>/verify/` — Faculty verify uploaded document

### 9. Faculty Portal, Analytics & Reports
- `GET /api/faculty/students/?faculty_email=hod.cse@institution.edu` — Scoped student directory (HOD sees all, Advisor sees section)
- `GET /api/faculty/students/<student_id>/` — Comprehensive student card with metrics
- `PATCH /api/faculty/students/<student_id>/advisor-notes/` — Save advisor remarks
- `GET /api/faculty/analytics/?dept=CSE` — Analytics: Attendance bands (<75%, 75-85%, >85%), CGPA bands, Placement score
- `GET /api/reports/academic-summary/?student_id=S1` — Academic summary data for report cards / transcripts
- `GET /api/reports/export/students-csv/?dept=CSE` — Export student dashboard to CSV
