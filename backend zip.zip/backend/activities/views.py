from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

from accounts.models import StudentProfile
from .models import (
    ClassActivityLog, FacultyActivityAssignment, FacultyActivityCompletion,
    Internship, SportActivity, CulturalActivity, HackathonActivity,
    WorkshopActivity, PaperPresentation, Skill, Project, Certification
)
from .serializers import (
    ClassActivityLogSerializer, FacultyActivityAssignmentSerializer,
    InternshipSerializer, SportActivitySerializer, CulturalActivitySerializer,
    HackathonActivitySerializer, WorkshopActivitySerializer,
    PaperPresentationSerializer, SkillSerializer, ProjectSerializer,
    CertificationSerializer
)

class StudentActivitiesOverviewView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        # Faculty assignments for student's department
        assignments = FacultyActivityAssignment.objects.filter(department__iexact=student.department)
        assignments_data = FacultyActivityAssignmentSerializer(assignments, many=True, context={'student': student}).data

        # Map facActivityDone object for student.html compatibility
        fac_done_map = {}
        for a in assignments:
            comp = FacultyActivityCompletion.objects.filter(activity=a, student=student).first()
            if comp and comp.is_done:
                fac_done_map[str(a.id)] = True

        return Response({
            'student_id': student.student_id,
            'reg_no': student.reg_no,
            'name': student.name,
            'faculty_activity_assignments': assignments_data,
            'facActivityDone': fac_done_map,
            'internships': InternshipSerializer(student.internships.all(), many=True).data,
            'sports': SportActivitySerializer(student.sports.all(), many=True).data,
            'cultural': CulturalActivitySerializer(student.cultural.all(), many=True).data,
            'hackathons': HackathonActivitySerializer(student.hackathons.all(), many=True).data,
            'workshops': WorkshopActivitySerializer(student.workshops.all(), many=True).data,
            'papers': PaperPresentationSerializer(student.papers.all(), many=True).data,
            'skills': [s.name for s in student.portfolio_skills.all()],
            'projects': ProjectSerializer(student.portfolio_projects.all(), many=True).data,
            'certifications': CertificationSerializer(student.portfolio_certifications.all(), many=True).data,
        }, status=status.HTTP_200_OK)


class ClassActivityLogView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        dept = request.query_params.get('dept')
        qs = ClassActivityLog.objects.all()
        if dept:
            qs = qs.filter(department__iexact=dept)
        return Response(ClassActivityLogSerializer(qs, many=True).data)

    def post(self, request):
        serializer = ClassActivityLogSerializer(data=request.data)
        if serializer.is_valid():
            act = serializer.save()
            return Response({'success': True, 'activity': serializer.data}, status=status.HTTP_201_CREATED)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class FacultyActivityAssignmentView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        dept = request.query_params.get('dept')
        qs = FacultyActivityAssignment.objects.all()
        if dept:
            qs = qs.filter(department__iexact=dept)
        return Response(FacultyActivityAssignmentSerializer(qs, many=True).data)

    def post(self, request):
        title = request.data.get('title')
        due = request.data.get('due') or request.data.get('due_date')
        by = request.data.get('by') or request.data.get('faculty_name', 'Faculty')
        dept = request.data.get('dept', 'CSE')

        if not title or not due:
            return Response({'error': 'Title and due date required.'}, status=status.HTTP_400_BAD_REQUEST)

        assignment = FacultyActivityAssignment.objects.create(
            title=title,
            due_date=due,
            faculty_name=by,
            department=dept
        )
        return Response({'success': True, 'assignment': FacultyActivityAssignmentSerializer(assignment).data}, status=status.HTTP_201_CREATED)


class ToggleFacultyActivityDoneView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, act_id):
        student_id = request.data.get('student_id')
        reg_no = request.data.get('reg_no')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        try:
            assignment = FacultyActivityAssignment.objects.get(pk=act_id)
        except FacultyActivityAssignment.DoesNotExist:
            return Response({'error': 'Activity not found.'}, status=status.HTTP_404_NOT_FOUND)

        comp, created = FacultyActivityCompletion.objects.get_or_create(
            activity=assignment,
            student=student,
            defaults={'is_done': True}
        )
        if not created:
            comp.is_done = not comp.is_done
            comp.save()

        return Response({
            'success': True,
            'activity_id': assignment.id,
            'is_done': comp.is_done
        }, status=status.HTTP_200_OK)


# Generic Helper for adding items to a student
def add_student_item(model_cls, serializer_cls, request):
    student_id = request.data.get('student_id')
    reg_no = request.data.get('reg_no')

    student = None
    if student_id:
        student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
    elif reg_no:
        student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
    else:
        student = StudentProfile.objects.first()

    if not student:
        return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

    data = request.data.copy()
    data['student'] = student.id
    serializer = serializer_cls(data=data)
    if serializer.is_valid():
        item = serializer.save()
        return Response({'success': True, 'item': serializer.data}, status=status.HTTP_201_CREATED)
    return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class AddInternshipView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(Internship, InternshipSerializer, request)

class AddSportView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(SportActivity, SportActivitySerializer, request)

class AddCulturalView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(CulturalActivity, CulturalActivitySerializer, request)

class AddHackathonView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(HackathonActivity, HackathonActivitySerializer, request)

class AddWorkshopView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(WorkshopActivity, WorkshopActivitySerializer, request)

class AddPaperView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(PaperPresentation, PaperPresentationSerializer, request)

class AddSkillView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        student_id = request.data.get('student_id')
        name = request.data.get('skill', request.data.get('name', '')).strip()
        student = StudentProfile.objects.filter(student_id__iexact=student_id).first() or StudentProfile.objects.first()
        if not student or not name:
            return Response({'error': 'Invalid request.'}, status=status.HTTP_400_BAD_REQUEST)
        skill, _ = Skill.objects.get_or_create(student=student, name=name)
        return Response({'success': True, 'skill': skill.name}, status=status.HTTP_201_CREATED)

    def delete(self, request):
        student_id = request.data.get('student_id')
        name = request.data.get('skill', request.data.get('name', '')).strip()
        student = StudentProfile.objects.filter(student_id__iexact=student_id).first() or StudentProfile.objects.first()
        if student and name:
            Skill.objects.filter(student=student, name=name).delete()
        return Response({'success': True, 'message': f'Skill {name} removed.'}, status=status.HTTP_200_OK)

class AddProjectView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(Project, ProjectSerializer, request)

    def delete(self, request, pk=None):
        Project.objects.filter(pk=pk).delete()
        return Response({'success': True, 'message': 'Project deleted.'})

class AddCertificationView(APIView):
    permission_classes = [AllowAny]
    def post(self, request):
        return add_student_item(Certification, CertificationSerializer, request)

    def delete(self, request, pk=None):
        Certification.objects.filter(pk=pk).delete()
        return Response({'success': True, 'message': 'Certification deleted.'})
