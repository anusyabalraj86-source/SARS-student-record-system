from django.urls import path
from .views import (
    StudentActivitiesOverviewView,
    ClassActivityLogView,
    FacultyActivityAssignmentView,
    ToggleFacultyActivityDoneView,
    AddInternshipView,
    AddSportView,
    AddCulturalView,
    AddHackathonView,
    AddWorkshopView,
    AddPaperView,
    AddSkillView,
    AddProjectView,
    AddCertificationView
)

urlpatterns = [
    # Activities overview for student
    path('activities/student/', StudentActivitiesOverviewView.as_view(), name='activities-student-overview'),

    # Class activity logs
    path('activities/class-log/', ClassActivityLogView.as_view(), name='class-activity-log'),

    # Faculty activity assignments
    path('activities/faculty/assignments/', FacultyActivityAssignmentView.as_view(), name='faculty-assignments'),
    path('activities/assignments/<int:act_id>/toggle/', ToggleFacultyActivityDoneView.as_view(), name='toggle-faculty-activity'),

    # Extra-curricular activities
    path('activities/internships/', AddInternshipView.as_view(), name='add-internship'),
    path('activities/sports/', AddSportView.as_view(), name='add-sport'),
    path('activities/cultural/', AddCulturalView.as_view(), name='add-cultural'),
    path('activities/hackathons/', AddHackathonView.as_view(), name='add-hackathon'),
    path('activities/workshops/', AddWorkshopView.as_view(), name='add-workshop'),
    path('activities/papers/', AddPaperView.as_view(), name='add-paper'),

    # Portfolio
    path('portfolio/skills/', AddSkillView.as_view(), name='portfolio-skills'),
    path('portfolio/projects/', AddProjectView.as_view(), name='portfolio-projects'),
    path('portfolio/projects/<int:pk>/', AddProjectView.as_view(), name='delete-portfolio-project'),
    path('portfolio/certifications/', AddCertificationView.as_view(), name='portfolio-certifications'),
    path('portfolio/certifications/<int:pk>/', AddCertificationView.as_view(), name='delete-portfolio-certification'),
]
