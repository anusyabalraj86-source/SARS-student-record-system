from django.db import models
from accounts.models import StudentProfile

class ClassActivityLog(models.Model):
    date = models.DateField()
    course_code = models.CharField(max_length=30)
    department = models.CharField(max_length=50, default='CSE')
    activity = models.CharField(max_length=255)
    faculty_name = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-id']

    def __str__(self):
        return f"{self.date} - {self.course_code}: {self.activity}"


class FacultyActivityAssignment(models.Model):
    title = models.CharField(max_length=255)
    due_date = models.DateField()
    faculty_name = models.CharField(max_length=150)
    department = models.CharField(max_length=50, default='CSE')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} (Due: {self.due_date})"


class FacultyActivityCompletion(models.Model):
    activity = models.ForeignKey(FacultyActivityAssignment, on_delete=models.CASCADE, related_name='completions')
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='completed_faculty_activities')
    is_done = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('activity', 'student')

    def __str__(self):
        return f"{self.student.name} - {self.activity.title} [{self.is_done}]"


class Internship(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='internships')
    company = models.CharField(max_length=150)
    duration = models.CharField(max_length=50)
    cert_url = models.URLField(blank=True)
    proj_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} at {self.company}"


class SportActivity(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='sports')
    name = models.CharField(max_length=100)
    level = models.CharField(max_length=50)  # District, State, National
    achievement = models.CharField(max_length=100)
    cert_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.name} ({self.achievement})"


class CulturalActivity(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='cultural')
    event = models.CharField(max_length=150)
    prize = models.CharField(max_length=100)
    cert_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.event}"


class HackathonActivity(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='hackathons')
    name = models.CharField(max_length=150)
    project = models.CharField(max_length=150)
    position = models.CharField(max_length=100)
    cert_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.name}"


class WorkshopActivity(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='workshops')
    event = models.CharField(max_length=150)
    date = models.CharField(max_length=50, blank=True)
    cert_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.event}"


class PaperPresentation(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='papers')
    title = models.CharField(max_length=255)
    conference = models.CharField(max_length=255)
    cert_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.title}"


class Skill(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='portfolio_skills')
    name = models.CharField(max_length=100)

    class Meta:
        unique_together = ('student', 'name')

    def __str__(self):
        return f"{self.student.name}: {self.name}"


class Project(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='portfolio_projects')
    title = models.CharField(max_length=150)
    tech = models.CharField(max_length=200)
    desc = models.TextField(blank=True)
    link = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.title}"


class Certification(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='portfolio_certifications')
    name = models.CharField(max_length=150)
    issuer = models.CharField(max_length=150)
    date = models.CharField(max_length=50, blank=True)
    link = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.name}"
