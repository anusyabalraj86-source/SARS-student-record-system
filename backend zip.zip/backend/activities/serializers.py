from rest_framework import serializers
from .models import (
    ClassActivityLog, FacultyActivityAssignment, FacultyActivityCompletion,
    Internship, SportActivity, CulturalActivity, HackathonActivity,
    WorkshopActivity, PaperPresentation, Skill, Project, Certification
)

class ClassActivityLogSerializer(serializers.ModelSerializer):
    by = serializers.CharField(source='faculty_name', read_only=True)
    course = serializers.CharField(source='course_code', read_only=True)

    class Meta:
        model = ClassActivityLog
        fields = ['id', 'date', 'course', 'course_code', 'department', 'activity', 'by', 'faculty_name']


class FacultyActivityAssignmentSerializer(serializers.ModelSerializer):
    by = serializers.CharField(source='faculty_name', read_only=True)
    due = serializers.DateField(source='due_date', read_only=True)
    is_done = serializers.SerializerMethodField()

    class Meta:
        model = FacultyActivityAssignment
        fields = ['id', 'title', 'due', 'due_date', 'by', 'faculty_name', 'department', 'is_done']

    def get_is_done(self, obj):
        student = self.context.get('student')
        if student:
            comp = FacultyActivityCompletion.objects.filter(activity=obj, student=student).first()
            return comp.is_done if comp else False
        return False


class InternshipSerializer(serializers.ModelSerializer):
    class Meta:
        model = Internship
        fields = '__all__'


class SportActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = SportActivity
        fields = '__all__'


class CulturalActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = CulturalActivity
        fields = '__all__'


class HackathonActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = HackathonActivity
        fields = '__all__'


class WorkshopActivitySerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkshopActivity
        fields = '__all__'


class PaperPresentationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaperPresentation
        fields = '__all__'


class SkillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Skill
        fields = '__all__'


class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = '__all__'


class CertificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Certification
        fields = '__all__'
