from django.contrib import admin
from .models import (
    ClassActivityLog, FacultyActivityAssignment, FacultyActivityCompletion,
    Internship, SportActivity, CulturalActivity, HackathonActivity,
    WorkshopActivity, PaperPresentation, Skill, Project, Certification
)

@admin.register(ClassActivityLog)
class ClassActivityLogAdmin(admin.ModelAdmin):
    list_display = ('date', 'course_code', 'activity', 'faculty_name', 'department')
    search_fields = ('course_code', 'activity', 'faculty_name')
    list_filter = ('department', 'date')


@admin.register(FacultyActivityAssignment)
class FacultyActivityAssignmentAdmin(admin.ModelAdmin):
    list_display = ('title', 'due_date', 'faculty_name', 'department')
    search_fields = ('title', 'faculty_name')
    list_filter = ('department', 'due_date')


@admin.register(FacultyActivityCompletion)
class FacultyActivityCompletionAdmin(admin.ModelAdmin):
    list_display = ('student', 'activity', 'is_done', 'updated_at')
    list_filter = ('is_done',)


@admin.register(Internship)
class InternshipAdmin(admin.ModelAdmin):
    list_display = ('student', 'company', 'duration')
    search_fields = ('student__name', 'company')


@admin.register(SportActivity)
class SportActivityAdmin(admin.ModelAdmin):
    list_display = ('student', 'name', 'level', 'achievement')
    search_fields = ('student__name', 'name')


@admin.register(CulturalActivity)
class CulturalActivityAdmin(admin.ModelAdmin):
    list_display = ('student', 'event', 'prize')
    search_fields = ('student__name', 'event')


@admin.register(HackathonActivity)
class HackathonActivityAdmin(admin.ModelAdmin):
    list_display = ('student', 'name', 'project', 'position')
    search_fields = ('student__name', 'name', 'project')


@admin.register(WorkshopActivity)
class WorkshopActivityAdmin(admin.ModelAdmin):
    list_display = ('student', 'event', 'date')
    search_fields = ('student__name', 'event')


@admin.register(PaperPresentation)
class PaperPresentationAdmin(admin.ModelAdmin):
    list_display = ('student', 'title', 'conference')
    search_fields = ('student__name', 'title')


@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ('student', 'name')
    search_fields = ('student__name', 'name')


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('student', 'title', 'tech')
    search_fields = ('student__name', 'title', 'tech')


@admin.register(Certification)
class CertificationAdmin(admin.ModelAdmin):
    list_display = ('student', 'name', 'issuer', 'date')
    search_fields = ('student__name', 'name', 'issuer')
