"""
Seed script to populate SARS backend SQLite database with initial data matching student.html.
Run with: python manage.py shell < seed_data.py
Or: python seed_data.py
"""

import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sars_backend.settings')
django.setup()

from accounts.models import User, StudentProfile, FacultyProfile
from academics.models import Subject, SubjectMark, DailyClassLog, DailyLogMessage
from attendance.models import AttendanceRecord, ParentAlert
from lms.models import LMSCourse, LearningMaterial, Homework, HomeworkSubmission
from activities.models import (
    ClassActivityLog, FacultyActivityAssignment, FacultyActivityCompletion,
    Internship, SportActivity, CulturalActivity, HackathonActivity,
    WorkshopActivity, PaperPresentation, Skill, Project, Certification
)
from communication.models import Notification, NotificationReply, DirectMessage

def seed_all():
    print("--- Seeding SARS Database ---")

    # 1. Create Admin Superuser
    admin_email = "admin@institution.edu"
    if not User.objects.filter(email=admin_email).exists():
        admin_user = User.objects.create_superuser(
            username="admin",
            email=admin_email,
            password="adminpassword123",
            role=User.ROLE_ADMIN,
            first_name="SARS",
            last_name="Administrator"
        )
        print("Created Superuser: admin@institution.edu / adminpassword123")
    else:
        print("Superuser already exists.")

    # 2. Create Faculty Accounts
    faculty_list = [
        {
            'email': 'hod.cse@institution.edu',
            'name': 'Dr. K. Ramesh',
            'dept': 'CSE',
            'role': 'HOD',
            'role_label': 'HOD, Computer Science & Engineering',
            'sections': '',
            'subject': ''
        },
        {
            'email': 'advisor.cse.a@institution.edu',
            'name': 'Prof. M. Devi',
            'dept': 'CSE',
            'role': 'Advisor',
            'role_label': 'Class Advisor, CSE - Section A',
            'sections': 'A',
            'subject': ''
        },
        {
            'email': 'advisor.cse.b@institution.edu',
            'name': 'Prof. J. Kumar',
            'dept': 'CSE',
            'role': 'Advisor',
            'role_label': 'Class Advisor, CSE - Section B',
            'sections': 'B',
            'subject': ''
        },
        {
            'email': 'staff.cse@institution.edu',
            'name': 'Prof. S. Latha',
            'dept': 'CSE',
            'role': 'Faculty',
            'role_label': 'Faculty (Subject Handler), CSE',
            'sections': 'A,B',
            'subject': 'CS305 - Database Management Systems'
        }
    ]

    for f_data in faculty_list:
        if not User.objects.filter(email=f_data['email']).exists():
            f_user = User.objects.create_user(
                username=f_data['email'],
                email=f_data['email'],
                password="faculty@123",
                first_name=f_data['name'],
                role=User.ROLE_FACULTY
            )
            FacultyProfile.objects.create(
                user=f_user,
                employee_id=f"FAC_{f_data['role']}_{f_data['dept']}",
                name=f_data['name'],
                email=f_data['email'],
                department=f_data['dept'],
                role=f_data['role'],
                role_label=f_data['role_label'],
                sections=f_data['sections'],
                subject=f_data['subject']
            )
            print(f"Created Faculty: {f_data['name']} ({f_data['email']}) / faculty@123")
        else:
            print(f"Faculty {f_data['email']} already exists.")

    # 3. Create Demo Student (Aditi Sharma)
    st_email = "aditi.s@inst.edu"
    st_reg = "21CSE045"
    if not User.objects.filter(email=st_email).exists():
        st_user = User.objects.create_user(
            username=st_reg,
            email=st_email,
            password="aditi@123",
            first_name="Aditi",
            last_name="Sharma",
            role=User.ROLE_STUDENT
        )
        student = StudentProfile.objects.create(
            user=st_user,
            student_id="S1",
            reg_no=st_reg,
            name="Aditi Sharma",
            department="CSE",
            year="3rd Year",
            section="A",
            email=st_email,
            phone="9843322110",
            gender="Girl",
            dob="12-04-2004",
            blood_group="B+",
            community="BC",
            address="14, Anna Nagar, Coimbatore",
            aadhar_masked="XXXX XXXX 8341",
            tenth_pct=94.0,
            twelfth_pct=96.0,
            twelfth_cutoff=195.0,
            physics_marks=88.0,
            chemistry_marks=90.0,
            maths_marks=92.0,
            group_12="CS",
            resident_type="Day Scholar",
            bus_route="Route 4 - Peelamedu",
            bus_no="Bus 4",
            boarding_point="Peelamedu",
            father_name="Mr. Rajesh Sharma",
            mother_name="Mrs. Sunita Sharma",
            father_phone="9843311100",
            mother_phone="9843311150",
            parent_name="Mr. Rajesh Sharma",
            parent_phone="9843311100",
            annual_income=450000.0,
            github_id="aditisharma-dev",
            leetcode_id="aditi_codes",
            linkedin_id="aditi-sharma-cse"
        )
        print(f"Created Student: {student.name} ({student.reg_no}) / aditi@123")
    else:
        student = StudentProfile.objects.get(email=st_email)
        print("Student Aditi Sharma already exists.")

    # 4. Create Subjects & Marks
    semesters_data = [
        {
            'sem': 1,
            'subjects': [
                {'code': 'CS101', 'name': 'Programming in C', 'credits': 4, 'grade': 'A+', 'i1': 88, 'i2': 90, 'i3': 85, 'model': 87},
                {'code': 'MA101', 'name': 'Engineering Mathematics I', 'credits': 4, 'grade': 'A', 'i1': 82, 'i2': 80, 'i3': 84, 'model': 81},
                {'code': 'CS102', 'name': 'Digital Logic Design', 'credits': 3, 'grade': 'A', 'i1': 85, 'i2': 83, 'i3': 86, 'model': 84},
                {'code': 'PH101', 'name': 'Physics for Engineers', 'credits': 3, 'grade': 'B+', 'i1': 76, 'i2': 74, 'i3': 78, 'model': 75},
                {'code': 'EN101', 'name': 'Communicative English', 'credits': 3, 'grade': 'A', 'i1': 84, 'i2': 86, 'i3': 83, 'model': 85},
                {'code': 'ME101', 'name': 'Engineering Graphics', 'credits': 3, 'grade': 'A+', 'i1': 90, 'i2': 92, 'i3': 89, 'model': 91},
            ]
        },
        {
            'sem': 2,
            'subjects': [
                {'code': 'CS201', 'name': 'Data Structures', 'credits': 4, 'grade': 'A+', 'i1': 91, 'i2': 89, 'i3': 92, 'model': 90},
                {'code': 'MA201', 'name': 'Engineering Mathematics II', 'credits': 4, 'grade': 'A', 'i1': 83, 'i2': 81, 'i3': 85, 'model': 82},
                {'code': 'CS202', 'name': 'Object Oriented Programming', 'credits': 4, 'grade': 'A+', 'i1': 90, 'i2': 88, 'i3': 91, 'model': 89},
                {'code': 'EE201', 'name': 'Electric Circuit Theory', 'credits': 3, 'grade': 'A', 'i1': 82, 'i2': 84, 'i3': 80, 'model': 83},
                {'code': 'CH201', 'name': 'Environmental Science', 'credits': 3, 'grade': 'A', 'i1': 85, 'i2': 83, 'i3': 87, 'model': 84},
                {'code': 'EN201', 'name': 'Professional Communication', 'credits': 3, 'grade': 'A', 'i1': 84, 'i2': 82, 'i3': 86, 'model': 83},
            ]
        },
        {
            'sem': 3,
            'subjects': [
                {'code': 'CS301', 'name': 'Database Management Systems', 'credits': 4, 'grade': 'A+', 'i1': 92, 'i2': 90, 'i3': 93, 'model': 91},
                {'code': 'CS302', 'name': 'Operating Systems', 'credits': 4, 'grade': 'A+', 'i1': 90, 'i2': 91, 'i3': 89, 'model': 92},
                {'code': 'CS303', 'name': 'Design and Analysis of Algorithms', 'credits': 4, 'grade': 'A', 'i1': 84, 'i2': 86, 'i3': 83, 'model': 85},
                {'code': 'CS304', 'name': 'Computer Organization', 'credits': 4, 'grade': 'A', 'i1': 83, 'i2': 85, 'i3': 84, 'model': 82},
                {'code': 'MA301', 'name': 'Discrete Mathematics', 'credits': 4, 'grade': 'A', 'i1': 82, 'i2': 84, 'i3': 80, 'model': 83},
                {'code': 'CS305P', 'name': 'OOP Lab', 'credits': 2, 'grade': 'O', 'i1': 95, 'i2': 96, 'i3': 94, 'model': 97},
            ]
        }
    ]

    for sem_info in semesters_data:
        sem = sem_info['sem']
        for sub in sem_info['subjects']:
            subj_obj, _ = Subject.objects.get_or_create(
                code=sub['code'],
                defaults={
                    'name': sub['name'],
                    'department': 'CSE',
                    'semester': sem,
                    'credits': sub['credits']
                }
            )
            SubjectMark.objects.update_or_create(
                student=student,
                subject=subj_obj,
                defaults={
                    'semester': sem,
                    'i1': sub['i1'],
                    'i2': sub['i2'],
                    'i3': sub['i3'],
                    'model_exam': sub['model'],
                    'grade': sub['grade'],
                    'is_arrear': (sub['grade'] == 'F')
                }
            )
    print("Seeded subjects and marks.")

    # 5. Seed Attendance for Aditi Sharma
    attendance_dates = {
        '2026-07-01': 'P', '2026-07-02': 'P', '2026-07-03': 'A', '2026-07-06': 'P',
        '2026-07-07': 'P', '2026-07-08': 'P', '2026-07-09': 'A', '2026-07-10': 'P',
        '2026-07-13': 'P', '2026-07-14': 'P', '2026-07-15': 'P', '2026-07-16': 'P',
        '2026-07-17': 'P', '2026-07-20': 'P', '2026-07-21': 'P', '2026-07-22': 'P',
        '2026-07-23': 'P', '2026-07-24': 'P'
    }
    for d, st in attendance_dates.items():
        AttendanceRecord.objects.get_or_create(
            student=student,
            date=d,
            period=1,
            defaults={'status': st, 'marked_by': 'Prof. M. Devi'}
        )
    print("Seeded attendance records.")

    # 6. Seed Portfolio Skills, Projects, Certifications, Extra-curriculars
    skills = ['Python', 'React', 'SQL', 'Public Speaking', 'Django', 'Data Structures']
    for sk in skills:
        Skill.objects.get_or_create(student=student, name=sk)

    Project.objects.get_or_create(
        student=student,
        title='Smart Attendance System',
        defaults={
            'tech': 'React, Node.js, MongoDB',
            'desc': 'Face-recognition based automated attendance system with reporting.',
            'link': 'https://github.com/aditisharma-dev/smart-attendance'
        }
    )

    Certification.objects.get_or_create(
        student=student,
        name='AWS Cloud Practitioner',
        defaults={
            'issuer': 'Amazon Web Services',
            'date': '2026-03-10',
            'link': 'https://aws.amazon.com/verification'
        }
    )

    Internship.objects.get_or_create(
        student=student,
        company='Zoho Corp',
        defaults={
            'duration': '8 weeks',
            'cert_url': 'https://www.zohocorp.com',
            'proj_url': ''
        }
    )

    SportActivity.objects.get_or_create(
        student=student,
        name='Badminton',
        defaults={
            'level': 'District',
            'achievement': 'Runner-up',
            'cert_url': ''
        }
    )

    HackathonActivity.objects.get_or_create(
        student=student,
        name='Smart India Hackathon 2025',
        defaults={
            'project': 'AgriSense IoT',
            'position': 'Finalist',
            'cert_url': 'https://sih.gov.in'
        }
    )
    print("Seeded portfolio and extracurriculars.")

    # 7. Seed LMS Courses and Materials
    c1, _ = LMSCourse.objects.get_or_create(
        code='CS301',
        defaults={
            'title': 'Operating Systems',
            'faculty_name': 'Dr. K. Ramesh',
            'department': 'CSE',
            'semester': 3,
            'description': 'Process management, concurrency, memory management and file systems.'
        }
    )
    LearningMaterial.objects.get_or_create(course=c1, name='Unit 1 slides.pdf', defaults={'material_type': 'pdf'})
    LearningMaterial.objects.get_or_create(course=c1, name='Unit 2 notes.pdf', defaults={'material_type': 'pdf'})
    LearningMaterial.objects.get_or_create(course=c1, name='Silberschatz - Operating System Concepts', defaults={'material_type': 'book'})

    c2, _ = LMSCourse.objects.get_or_create(
        code='CS305',
        defaults={
            'title': 'Database Management Systems',
            'faculty_name': 'Prof. S. Latha',
            'department': 'CSE',
            'semester': 3,
            'description': 'Relational data models, SQL, ER modeling, normalization and transactions.'
        }
    )
    LearningMaterial.objects.get_or_create(course=c2, name='ER-modeling handout.pdf', defaults={'material_type': 'pdf'})
    LearningMaterial.objects.get_or_create(course=c2, name='Normalization slides.ppt', defaults={'material_type': 'ppt'})

    # 8. Seed Homework
    hw1, _ = Homework.objects.get_or_create(
        course_code='CS301',
        title='Assignment 3 - Process Scheduling',
        defaults={
            'description': 'Solve problems 4-9 from chapter 5 (FCFS, SJF, Round Robin).',
            'due_date': '2026-07-28',
            'posted_by': 'Dr. K. Ramesh',
            'department': 'CSE',
            'section': 'A'
        }
    )
    hw2, _ = Homework.objects.get_or_create(
        course_code='CS305',
        title='ER Diagram - Library Management',
        defaults={
            'description': 'Design and submit an ER diagram for a college library management system.',
            'due_date': '2026-07-30',
            'posted_by': 'Prof. S. Latha',
            'department': 'CSE',
            'section': 'A'
        }
    )
    HomeworkSubmission.objects.get_or_create(homework=hw1, student=student, defaults={'is_done': True})
    HomeworkSubmission.objects.get_or_create(homework=hw2, student=student, defaults={'is_done': False})

    # 9. Seed Daily Class Log
    DailyClassLog.objects.get_or_create(
        date='2026-07-22',
        course_code='CS301',
        defaults={
            'course_title': 'Operating Systems',
            'department': 'CSE',
            'topic': 'Introduction to CPU scheduling - goals and criteria',
            'faculty_name': 'Dr. K. Ramesh'
        }
    )
    DailyClassLog.objects.get_or_create(
        date='2026-07-23',
        course_code='CS301',
        defaults={
            'course_title': 'Operating Systems',
            'department': 'CSE',
            'topic': 'FCFS and SJF scheduling algorithms with examples',
            'faculty_name': 'Dr. K. Ramesh'
        }
    )

    # 10. Seed Notifications
    n1, _ = Notification.objects.get_or_create(
        title='Hackathon Registrations Open',
        defaults={
            'body': 'Register for the Smart India Hackathon internal round by 30 July. Teams of 4, cross-department allowed.',
            'date': '2026-07-20',
            'posted_by': 'Dr. K. Ramesh, HOD CSE',
            'department': 'CSE'
        }
    )
    Notification.objects.get_or_create(
        title='Semester 4 Fee Due Date',
        defaults={
            'body': 'Semester 4 tuition fee payment closes on 5 August. Late fee applies after this date.',
            'date': '2026-07-18',
            'posted_by': 'Admin Office',
            'department': 'ALL'
        }
    )

    # 11. Seed Faculty Assigned Activity
    FacultyActivityAssignment.objects.get_or_create(
        title='Prepare a 5-minute presentation summarising FCFS vs SJF scheduling',
        defaults={
            'due_date': '2026-07-27',
            'faculty_name': 'Dr. K. Ramesh',
            'department': 'CSE'
        }
    )

    print("--- Seeding Completed Successfully! ---")

if __name__ == '__main__':
    seed_all()
