from django.contrib import admin
from .models import AttendanceRecord, ParentAlert

@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display = ('student', 'date', 'status', 'period', 'marked_by')
    search_fields = ('student__name', 'student__reg_no')
    list_filter = ('status', 'date', 'period')


@admin.register(ParentAlert)
class ParentAlertAdmin(admin.ModelAdmin):
    list_display = ('name', 'reg_no', 'date', 'phone', 'time', 'status')
    search_fields = ('name', 'reg_no', 'phone')
    list_filter = ('date', 'status')
