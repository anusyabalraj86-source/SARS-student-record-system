from django.urls import path
from .views import (
    StudentAttendanceView,
    SaveAttendanceView,
    ParentAlertListView,
    SendParentAlertView
)

urlpatterns = [
    path('attendance/student/', StudentAttendanceView.as_view(), name='student-attendance'),
    path('attendance/mark/', SaveAttendanceView.as_view(), name='mark-attendance'),
    path('attendance/parent-alerts/', ParentAlertListView.as_view(), name='parent-alerts-list'),
    path('attendance/parent-alert/send/', SendParentAlertView.as_view(), name='send-parent-alert'),
]
