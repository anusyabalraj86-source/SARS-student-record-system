from django.db import models
from accounts.models import StudentProfile

class AttendanceRecord(models.Model):
    STATUS_CHOICES = [
        ('P', 'Present'),
        ('A', 'Absent'),
        ('OD', 'On Duty'),
    ]

    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='attendance_records')
    date = models.DateField(db_index=True)
    status = models.CharField(max_length=5, choices=STATUS_CHOICES, default='P')
    marked_by = models.CharField(max_length=150, blank=True)
    period = models.IntegerField(default=1)  # Period 1 or whole day
    remarks = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('student', 'date', 'period')
        ordering = ['-date']

    def __str__(self):
        return f"{self.student.name} - {self.date} [{self.status}]"


class ParentAlert(models.Model):
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='parent_alerts')
    name = models.CharField(max_length=150)
    reg_no = models.CharField(max_length=50)
    date = models.DateField()
    phone = models.CharField(max_length=30)
    time = models.CharField(max_length=20)
    message = models.TextField()
    status = models.CharField(max_length=30, default='SENT')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Alert to {self.phone} for {self.name} on {self.date}"
