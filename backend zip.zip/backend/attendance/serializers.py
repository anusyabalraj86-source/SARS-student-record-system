from rest_framework import serializers
from .models import AttendanceRecord, ParentAlert

class AttendanceRecordSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.name', read_only=True)
    reg_no = serializers.CharField(source='student.reg_no', read_only=True)

    class Meta:
        model = AttendanceRecord
        fields = '__all__'


class ParentAlertSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParentAlert
        fields = '__all__'
