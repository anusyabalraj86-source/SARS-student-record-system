from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from datetime import datetime

from accounts.models import StudentProfile
from .models import AttendanceRecord, ParentAlert
from .serializers import AttendanceRecordSerializer, ParentAlertSerializer

class StudentAttendanceView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        records = AttendanceRecord.objects.filter(student=student).order_by('date')
        att_dict = {}
        present_count = 0
        absent_count = 0
        od_count = 0

        for r in records:
            d_str = r.date.strftime('%Y-%m-%d')
            att_dict[d_str] = r.status
            if r.status == 'P':
                present_count += 1
            elif r.status == 'A':
                absent_count += 1
            elif r.status == 'OD':
                od_count += 1

        total = present_count + absent_count + od_count
        pct = round(((present_count + od_count) / total) * 100, 1) if total > 0 else 0.0

        return Response({
            'student_id': student.student_id,
            'reg_no': student.reg_no,
            'name': student.name,
            'attendance': att_dict,
            'total_working_days': total,
            'present_count': present_count,
            'absent_count': absent_count,
            'od_count': od_count,
            'attendance_percentage': pct
        }, status=status.HTTP_200_OK)


class SaveAttendanceView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        # Can accept single record or bulk list
        # Payload example:
        # { "date": "2026-07-24", "marked_by": "Dr. K. Ramesh", "records": [ {"student_id": "S1", "status": "P"}, ... ] }
        data = request.data
        date_str = data.get('date')
        if not date_str:
            date_str = datetime.now().strftime('%Y-%m-%d')

        marked_by = data.get('marked_by', 'Faculty')
        period = int(data.get('period', 1))

        # Check if bulk records
        bulk_records = data.get('records')
        saved_count = 0
        absentees = []

        if bulk_records and isinstance(bulk_records, list):
            for item in bulk_records:
                sid = item.get('student_id')
                reg = item.get('reg_no')
                stat = item.get('status', 'P')
                student = None
                if sid:
                    student = StudentProfile.objects.filter(student_id__iexact=sid).first()
                elif reg:
                    student = StudentProfile.objects.filter(reg_no__iexact=reg).first()

                if student:
                    AttendanceRecord.objects.update_or_create(
                        student=student,
                        date=date_str,
                        period=period,
                        defaults={'status': stat, 'marked_by': marked_by}
                    )
                    saved_count += 1
                    if stat == 'A':
                        absentees.append(student)
        else:
            # Single entry
            sid = data.get('student_id')
            reg = data.get('reg_no')
            stat = data.get('status', 'P')
            student = None
            if sid:
                student = StudentProfile.objects.filter(student_id__iexact=sid).first()
            elif reg:
                student = StudentProfile.objects.filter(reg_no__iexact=reg).first()

            if student:
                AttendanceRecord.objects.update_or_create(
                    student=student,
                    date=date_str,
                    period=period,
                    defaults={'status': stat, 'marked_by': marked_by}
                )
                saved_count += 1
                if stat == 'A':
                    absentees.append(student)

        # Auto create ParentAlert logs for absentees if requested
        auto_alert = data.get('send_parent_alerts', True)
        if auto_alert and absentees:
            curr_time = datetime.now().strftime('%H:%M')
            for s in absentees:
                phone = s.parent_phone or s.father_phone or s.mother_phone or '9840000000'
                msg = f"Dear Parent, your ward {s.name} ({s.reg_no}) was marked ABSENT today ({date_str}) and did not attend classes. SARS Attendance Dept."
                ParentAlert.objects.get_or_create(
                    student=s,
                    date=date_str,
                    defaults={
                        'name': s.name,
                        'reg_no': s.reg_no,
                        'phone': phone,
                        'time': curr_time,
                        'message': msg,
                        'status': 'SENT'
                    }
                )

        return Response({
            'success': True,
            'message': f"Saved attendance for {saved_count} student(s).",
            'date': date_str,
            'absentees_flagged': len(absentees)
        }, status=status.HTTP_200_OK)


class ParentAlertListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        dept = request.query_params.get('dept')
        qs = ParentAlert.objects.all().select_related('student')
        if dept:
            qs = qs.filter(student__department__iexact=dept)
        serializer = ParentAlertSerializer(qs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class SendParentAlertView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        student_id = request.data.get('student_id')
        reg_no = request.data.get('reg_no')
        date_str = request.data.get('date', datetime.now().strftime('%Y-%m-%d'))
        
        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        phone = student.parent_phone or student.father_phone or student.mother_phone or '9840000000'
        curr_time = datetime.now().strftime('%H:%M')
        msg = f"Dear Parent, your ward {student.name} ({student.reg_no}) was marked ABSENT today ({date_str}) and did not attend classes. SARS Attendance Dept."

        alert, created = ParentAlert.objects.get_or_create(
            student=student,
            date=date_str,
            defaults={
                'name': student.name,
                'reg_no': student.reg_no,
                'phone': phone,
                'time': curr_time,
                'message': msg,
                'status': 'SENT'
            }
        )

        return Response({
            'success': True,
            'message': f"Parent alert sent to {phone}.",
            'alert': ParentAlertSerializer(alert).data
        }, status=status.HTTP_201_CREATED)
