from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import User, StudentProfile, FacultyProfile

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'role']


class StudentProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    profile_photo_url = serializers.SerializerMethodField()

    class Meta:
        model = StudentProfile
        fields = '__all__'

    def get_profile_photo_url(self, obj):
        if obj.profile_photo:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.profile_photo.url)
            return obj.profile_photo.url
        return ''


class StudentRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)
    confirm_password = serializers.CharField(write_only=True, min_length=6, required=False)

    class Meta:
        model = StudentProfile
        fields = [
            'name', 'reg_no', 'department', 'year', 'section', 'email', 'phone',
            'password', 'confirm_password', 'dob', 'gender', 'blood_group', 'community',
            'tenth_pct', 'twelfth_pct', 'twelfth_cutoff', 'physics_marks', 'chemistry_marks',
            'maths_marks', 'group_12', 'father_name', 'mother_name', 'father_phone', 'mother_phone',
            'parent_name', 'parent_phone', 'address', 'resident_type', 'bus_no', 'bus_route',
            'boarding_point', 'annual_income', 'aadhar_masked', 'apaar_id', 'github_id',
            'leetcode_id', 'linkedin_id', 'profile_photo'
        ]

    def validate(self, data):
        email = data.get('email')
        reg_no = data.get('reg_no')
        if User.objects.filter(email__iexact=email).exists():
            raise serializers.ValidationError({'email': 'A user with this email already exists.'})
        if StudentProfile.objects.filter(reg_no__iexact=reg_no).exists():
            raise serializers.ValidationError({'reg_no': 'A student with this Register Number already exists.'})
        
        pass1 = data.get('password')
        pass2 = data.get('confirm_password')
        if pass2 and pass1 != pass2:
            raise serializers.ValidationError({'confirm_password': 'Passwords do not match.'})
        return data

    def create(self, validated_data):
        password = validated_data.pop('password')
        validated_data.pop('confirm_password', None)
        email = validated_data.get('email')
        reg_no = validated_data.get('reg_no')
        name = validated_data.get('name')

        # Create user with secure password hashing
        user = User.objects.create_user(
            username=reg_no,
            email=email,
            password=password,
            first_name=name,
            role=User.ROLE_STUDENT
        )

        # Generate unique student_id if not present
        count = StudentProfile.objects.count() + 1
        student_id = f"S{count}"
        
        profile = StudentProfile.objects.create(
            user=user,
            student_id=student_id,
            **validated_data
        )
        return profile


class StudentLoginSerializer(serializers.Serializer):
    identifier = serializers.CharField(help_text="Email or Register Number")
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        identifier = data.get('identifier', '').strip()
        password = data.get('password', '')

        user = None
        # Try by email
        if '@' in identifier:
            try:
                user_obj = User.objects.get(email__iexact=identifier)
                if user_obj.check_password(password):
                    user = user_obj
            except User.DoesNotExist:
                pass
        
        # Try by reg_no / username
        if not user:
            try:
                user_obj = User.objects.get(username__iexact=identifier)
                if user_obj.check_password(password):
                    user = user_obj
            except User.DoesNotExist:
                try:
                    profile = StudentProfile.objects.get(reg_no__iexact=identifier)
                    if profile.user.check_password(password):
                        user = profile.user
                except StudentProfile.DoesNotExist:
                    pass

        if not user:
            raise serializers.ValidationError("Invalid credentials. Please check your email/register number and password.")
        
        if user.role != User.ROLE_STUDENT and not user.is_staff:
            raise serializers.ValidationError("Account is not registered as a student.")

        data['user'] = user
        return data


class FacultyLoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        email = data.get('email', '').strip()
        password = data.get('password', '')

        try:
            user = User.objects.get(email__iexact=email)
            if not user.check_password(password):
                raise serializers.ValidationError("Invalid password.")
        except User.DoesNotExist:
            raise serializers.ValidationError("Faculty member not found with this email.")

        if user.role != User.ROLE_FACULTY and not user.is_staff:
            raise serializers.ValidationError("This account does not have faculty privileges.")

        data['user'] = user
        return data


class FacultyProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    sections_list = serializers.SerializerMethodField()

    class Meta:
        model = FacultyProfile
        fields = '__all__'

    def get_sections_list(self, obj):
        return obj.get_sections_list()


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True, min_length=6)
