from django.urls import path
from .views import (
    StudentRegisterView,
    StudentLoginView,
    FacultyLoginView,
    StudentProfileDetailView,
    ProfilePhotoUploadView,
    ChangePasswordView
)

urlpatterns = [
    # Auth endpoints
    path('auth/register/', StudentRegisterView.as_view(), name='student-register'),
    path('auth/login/student/', StudentLoginView.as_view(), name='student-login'),
    path('auth/login/faculty/', FacultyLoginView.as_view(), name='faculty-login'),
    path('auth/change-password/', ChangePasswordView.as_view(), name='change-password'),

    # Profile endpoints
    path('profile/student/', StudentProfileDetailView.as_view(), name='student-profile'),
    path('profile/student/photo/', ProfilePhotoUploadView.as_view(), name='student-profile-photo'),
]
