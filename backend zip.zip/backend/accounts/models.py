from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    ROLE_STUDENT = 'student'
    ROLE_FACULTY = 'faculty'
    ROLE_ADMIN = 'admin'
    ROLE_CHOICES = [
        (ROLE_STUDENT, 'Student'),
        (ROLE_FACULTY, 'Faculty'),
        (ROLE_ADMIN, 'Admin'),
    ]

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_STUDENT)
    email = models.EmailField(unique=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return f"{self.email} ({self.role})"


class StudentProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_profile')
    student_id = models.CharField(max_length=30, unique=True, default='S1')
    reg_no = models.CharField(max_length=50, unique=True, db_index=True)
    name = models.CharField(max_length=150)
    department = models.CharField(max_length=50, default='CSE')
    year = models.CharField(max_length=20, default='1st Year')
    section = models.CharField(max_length=10, default='A')
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    gender = models.CharField(max_length=20, blank=True)
    dob = models.CharField(max_length=20, blank=True)
    blood_group = models.CharField(max_length=10, blank=True)
    community = models.CharField(max_length=20, blank=True)
    annual_income = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    address = models.TextField(blank=True)

    # Transport / Residency
    resident_type = models.CharField(max_length=30, default='Day Scholar')  # Day Scholar / Hosteller
    bus_route = models.CharField(max_length=100, blank=True)
    bus_no = models.CharField(max_length=50, blank=True)
    boarding_point = models.CharField(max_length=100, blank=True)

    # 10th / 12th Academic Details
    tenth_pct = models.FloatField(default=0.0)
    twelfth_pct = models.FloatField(default=0.0)
    twelfth_cutoff = models.FloatField(default=0.0)
    physics_marks = models.FloatField(default=0.0)
    chemistry_marks = models.FloatField(default=0.0)
    maths_marks = models.FloatField(default=0.0)
    group_12 = models.CharField(max_length=50, blank=True)

    # Parent / Guardian Information
    father_name = models.CharField(max_length=100, blank=True)
    mother_name = models.CharField(max_length=100, blank=True)
    parent_name = models.CharField(max_length=100, blank=True)
    father_phone = models.CharField(max_length=20, blank=True)
    mother_phone = models.CharField(max_length=20, blank=True)
    parent_phone = models.CharField(max_length=20, blank=True)

    # Identity & Portfolios
    aadhar_masked = models.CharField(max_length=30, blank=True)
    apaar_id = models.CharField(max_length=50, blank=True)
    github_id = models.CharField(max_length=100, blank=True)
    leetcode_id = models.CharField(max_length=100, blank=True)
    linkedin_id = models.CharField(max_length=150, blank=True)
    resume_link = models.URLField(blank=True)

    profile_photo = models.ImageField(upload_to='profiles/', blank=True, null=True)

    # Faculty / Placement remarks
    placement_readiness_score = models.FloatField(default=0.0)
    advisor_remarks = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.reg_no}) - {self.department}"


class FacultyProfile(models.Model):
    ROLE_HOD = 'HOD'
    ROLE_ADVISOR = 'Advisor'
    ROLE_FACULTY = 'Faculty'
    FACULTY_ROLE_CHOICES = [
        (ROLE_HOD, 'HOD'),
        (ROLE_ADVISOR, 'Class Advisor'),
        (ROLE_FACULTY, 'Faculty (Subject Handler)'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='faculty_profile')
    employee_id = models.CharField(max_length=50, blank=True)
    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    department = models.CharField(max_length=50, default='CSE')
    role = models.CharField(max_length=30, choices=FACULTY_ROLE_CHOICES, default=ROLE_FACULTY)
    role_label = models.CharField(max_length=150, blank=True)
    sections = models.CharField(max_length=50, blank=True, help_text="Comma-separated sections e.g. 'A,B'")
    subject = models.CharField(max_length=150, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def get_sections_list(self):
        if not self.sections:
            return []
        return [s.strip() for s in self.sections.split(',') if s.strip()]

    def __str__(self):
        return f"{self.name} - {self.role} ({self.department})"
