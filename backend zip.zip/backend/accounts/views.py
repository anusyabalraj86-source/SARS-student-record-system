from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django.contrib.auth import login, logout

from .models import User, StudentProfile, FacultyProfile
from .serializers import (
    StudentRegistrationSerializer,
    StudentLoginSerializer,
    FacultyLoginSerializer,
    StudentProfileSerializer,
    FacultyProfileSerializer,
    ChangePasswordSerializer
)

class StudentRegisterView(APIView):
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request):
        serializer = StudentRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            profile = serializer.save()
            return Response({
                'success': True,
                'message': 'Student registered successfully.',
                'student': StudentProfileSerializer(profile, context={'request': request}).data
            }, status=status.HTTP_201_CREATED)
        return Response({
            'success': False,
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


class StudentLoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = StudentLoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            try:
                profile = user.student_profile
                data = StudentProfileSerializer(profile, context={'request': request}).data
            except StudentProfile.DoesNotExist:
                data = None

            return Response({
                'success': True,
                'role': 'student',
                'user_id': user.id,
                'email': user.email,
                'student_id': profile.student_id if profile else None,
                'reg_no': profile.reg_no if profile else None,
                'student': data,
                'message': f"Welcome {profile.name if profile else user.email}!"
            }, status=status.HTTP_200_OK)
        return Response({
            'success': False,
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


class FacultyLoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = FacultyLoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            try:
                faculty = user.faculty_profile
                faculty_data = FacultyProfileSerializer(faculty).data
            except FacultyProfile.DoesNotExist:
                # In case an admin logged in
                faculty = None
                faculty_data = {
                    'email': user.email,
                    'name': user.get_full_name() or user.username,
                    'role': 'HOD',
                    'department': 'CSE',
                    'sections_list': ['A', 'B'],
                }

            return Response({
                'success': True,
                'role': 'faculty',
                'faculty_role': faculty.role if faculty else 'HOD',
                'faculty': faculty_data,
                'message': f"Welcome {faculty.name if faculty else user.email}!"
            }, status=status.HTTP_200_OK)
        return Response({
            'success': False,
            'errors': serializer.errors
        }, status=status.HTTP_400_BAD_REQUEST)


class StudentProfileDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')
        
        profile = None
        if student_id:
            profile = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            profile = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        elif request.user.is_authenticated and hasattr(request.user, 'student_profile'):
            profile = request.user.student_profile
        else:
            profile = StudentProfile.objects.first()

        if not profile:
            return Response({'error': 'Student profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = StudentProfileSerializer(profile, context={'request': request})
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request):
        student_id = request.data.get('student_id') or request.query_params.get('student_id')
        reg_no = request.data.get('reg_no') or request.query_params.get('reg_no')

        profile = None
        if student_id:
            profile = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            profile = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        elif request.user.is_authenticated and hasattr(request.user, 'student_profile'):
            profile = request.user.student_profile
        else:
            profile = StudentProfile.objects.first()

        if not profile:
            return Response({'error': 'Student profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        serializer = StudentProfileSerializer(profile, data=request.data, partial=True, context={'request': request})
        if serializer.is_valid():
            serializer.save()
            return Response({'success': True, 'student': serializer.data}, status=status.HTTP_200_OK)
        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


class ProfilePhotoUploadView(APIView):
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request):
        student_id = request.data.get('student_id')
        reg_no = request.data.get('reg_no')
        photo = request.FILES.get('profile_photo')

        if not photo:
            return Response({'error': 'No image file provided.'}, status=status.HTTP_400_BAD_REQUEST)

        profile = None
        if student_id:
            profile = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            profile = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            profile = StudentProfile.objects.first()

        if not profile:
            return Response({'error': 'Student profile not found.'}, status=status.HTTP_404_NOT_FOUND)

        profile.profile_photo = photo
        profile.save()

        return Response({
            'success': True,
            'photo_url': request.build_absolute_uri(profile.profile_photo.url)
        }, status=status.HTTP_200_OK)


class ChangePasswordView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        if serializer.is_valid():
            email = request.data.get('email')
            student_id = request.data.get('student_id')
            user = None
            if email:
                user = User.objects.filter(email__iexact=email).first()
            elif student_id:
                prof = StudentProfile.objects.filter(student_id__iexact=student_id).first()
                if prof:
                    user = prof.user

            if not user:
                return Response({'error': 'User not found.'}, status=status.HTTP_404_NOT_FOUND)

            if not user.check_password(serializer.validated_data['old_password']):
                return Response({'error': 'Current password does not match.'}, status=status.HTTP_400_BAD_REQUEST)

            user.set_password(serializer.validated_data['new_password'])
            user.save()
            return Response({'success': True, 'message': 'Password updated successfully.'}, status=status.HTTP_200_OK)

        return Response({'success': False, 'errors': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
