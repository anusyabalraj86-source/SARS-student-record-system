from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, StudentProfile, FacultyProfile

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'role', 'is_staff', 'is_active')
    list_filter = ('role', 'is_staff', 'is_active')
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Role Info', {'fields': ('role',)}),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('Role Info', {'fields': ('role',)}),
    )


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('student_id', 'reg_no', 'name', 'department', 'year', 'section', 'email', 'phone')
    search_fields = ('student_id', 'reg_no', 'name', 'email', 'phone')
    list_filter = ('department', 'year', 'section', 'resident_type')


@admin.register(FacultyProfile)
class FacultyProfileAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'department', 'role', 'sections', 'subject')
    search_fields = ('name', 'email', 'employee_id')
    list_filter = ('department', 'role')
