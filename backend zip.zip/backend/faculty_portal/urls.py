from django.urls import path
from .views import (
    FacultyStudentListView,
    FacultyStudentDetailView,
    FacultyAnalyticsView,
    ExportStudentsCsvView,
    AcademicSummaryReportView
)

urlpatterns = [
    # Faculty Student Records & Management
    path('faculty/students/', FacultyStudentListView.as_view(), name='faculty-students-list'),
    path('faculty/students/<str:student_id>/', FacultyStudentDetailView.as_view(), name='faculty-student-detail'),
    path('faculty/students/<str:student_id>/advisor-notes/', FacultyStudentDetailView.as_view(), name='update-advisor-notes'),

    # Faculty Analytics
    path('faculty/analytics/', FacultyAnalyticsView.as_view(), name='faculty-analytics'),

    # Reports
    path('reports/academic-summary/', AcademicSummaryReportView.as_view(), name='academic-summary-report'),
    path('reports/export/students-csv/', ExportStudentsCsvView.as_view(), name='export-students-csv'),
]
