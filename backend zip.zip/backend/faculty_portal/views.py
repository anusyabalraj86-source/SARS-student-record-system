import csv
from django.http import HttpResponse
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny

from accounts.models import User, StudentProfile, FacultyProfile
from accounts.serializers import StudentProfileSerializer
from academics.models import SubjectMark
from attendance.models import AttendanceRecord

def get_faculty_accessible_students(faculty_email=None, faculty_role=None, dept=None, section=None):
    """
    Implements the exact access control logic from student.html:
    - HOD: always sees every section in department.
    - Advisor: restricted to assigned section(s).
    - Faculty: restricted to assigned section(s).
    """
    students_qs = StudentProfile.objects.all()

    faculty = None
    if faculty_email:
        faculty = FacultyProfile.objects.filter(email__iexact=faculty_email).first()

    if faculty:
        students_qs = students_qs.filter(department__iexact=faculty.department)
        if faculty.role != FacultyProfile.ROLE_HOD:
            sec_list = faculty.get_sections_list()
            if sec_list:
                students_qs = students_qs.filter(section__in=sec_list)
    elif dept:
        students_qs = students_qs.filter(department__iexact=dept)
        if section:
            students_qs = students_qs.filter(section__iexact=section)

    return students_qs


def calculate_student_academic_metrics(student):
    """Calculates CGPA, total credits, arrears, and attendance percentage."""
    marks = SubjectMark.objects.filter(student=student).select_related('subject')
    total_credits = 0
    weighted_pts = 0
    arrears_count = 0
    arrear_list = []

    for m in marks:
        c = m.subject.credits
        gp = m.grade_point
        total_credits += c
        weighted_pts += (c * gp)
        if m.grade == 'F':
            arrears_count += 1
            arrear_list.append(m.subject.code)

    cgpa = round(weighted_pts / total_credits, 2) if total_credits > 0 else 0.0

    # Attendance
    att_records = AttendanceRecord.objects.filter(student=student)
    p_count = att_records.filter(status='P').count()
    od_count = att_records.filter(status='OD').count()
    total_days = att_records.count()
    att_pct = round(((p_count + od_count) / total_days) * 100, 1) if total_days > 0 else 0.0

    # Placement score computation (aligned with student.html placementScore())
    # Score = min(100, (CGPA*8) + (skills*3) + (certs*4) + (hackathons*5) - (arrears*10))
    skill_count = student.portfolio_skills.count()
    cert_count = student.portfolio_certifications.count()
    hack_count = student.hackathons.count()
    base_score = (cgpa * 8) + (skill_count * 3) + (cert_count * 4) + (hack_count * 5) - (arrears_count * 10)
    placement_score = max(0, min(100, round(base_score, 1)))

    return {
        'cgpa': cgpa,
        'total_credits': total_credits,
        'arrears_count': arrears_count,
        'arrears': arrear_list,
        'attendance_pct': att_pct,
        'placement_score': placement_score
    }


class FacultyStudentListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        faculty_email = request.query_params.get('faculty_email')
        dept = request.query_params.get('dept')
        section = request.query_params.get('section')
        year = request.query_params.get('year')
        search = request.query_params.get('search')

        qs = get_faculty_accessible_students(faculty_email, dept=dept, section=section)

        if year:
            qs = qs.filter(year__iexact=year)
        if search:
            from django.db.models import Q
            qs = qs.filter(Q(name__icontains=search) | Q(reg_no__icontains=search) | Q(student_id__icontains=search))

        results = []
        for s in qs:
            metrics = calculate_student_academic_metrics(s)
            results.append({
                'id': s.student_id,
                'student_id': s.student_id,
                'db_id': s.id,
                'name': s.name,
                'reg': s.reg_no,
                'reg_no': s.reg_no,
                'dept': s.department,
                'year': s.year,
                'section': s.section,
                'email': s.email,
                'phone': s.phone,
                'parent_name': s.parent_name or s.father_name,
                'parent_phone': s.parent_phone or s.father_phone,
                'cgpa': metrics['cgpa'],
                'attendance_pct': metrics['attendance_pct'],
                'arrears_count': metrics['arrears_count'],
                'placement_score': metrics['placement_score'],
                'advisor_remarks': s.advisor_remarks
            })

        return Response(results, status=status.HTTP_200_OK)


class FacultyStudentDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, student_id):
        student = StudentProfile.objects.filter(student_id__iexact=student_id).first() or StudentProfile.objects.filter(reg_no__iexact=student_id).first()
        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        metrics = calculate_student_academic_metrics(student)
        serializer = StudentProfileSerializer(student, context={'request': request})
        data = serializer.data
        data['metrics'] = metrics
        return Response(data, status=status.HTTP_200_OK)

    def patch(self, request, student_id):
        student = StudentProfile.objects.filter(student_id__iexact=student_id).first() or StudentProfile.objects.filter(reg_no__iexact=student_id).first()
        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        remarks = request.data.get('advisor_remarks')
        if remarks is not None:
            student.advisor_remarks = remarks
            student.save()

        return Response({'success': True, 'advisor_remarks': student.advisor_remarks}, status=status.HTTP_200_OK)


class FacultyAnalyticsView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        faculty_email = request.query_params.get('faculty_email')
        dept = request.query_params.get('dept', 'CSE')

        qs = get_faculty_accessible_students(faculty_email, dept=dept)
        total_students = qs.count()

        if total_students == 0:
            return Response({
                'total_students': 0,
                'average_attendance': 0,
                'attendance_bands': {'critical_lt_75': 0, 'average_75_85': 0, 'good_gt_85': 0},
                'cgpa_bands': {'gt_9': 0, 'between_8_9': 0, 'between_7_8': 0, 'lt_7': 0},
                'total_arrears': 0,
                'average_placement_score': 0
            })

        att_bands = {'critical_lt_75': 0, 'average_75_85': 0, 'good_gt_85': 0}
        cgpa_bands = {'gt_9': 0, 'between_8_9': 0, 'between_7_8': 0, 'lt_7': 0}
        total_att_sum = 0
        total_arrears = 0
        total_placement_score = 0

        for s in qs:
            metrics = calculate_student_academic_metrics(s)
            att = metrics['attendance_pct']
            cgpa = metrics['cgpa']
            arr = metrics['arrears_count']
            ps = metrics['placement_score']

            total_att_sum += att
            total_arrears += arr
            total_placement_score += ps

            if att < 75:
                att_bands['critical_lt_75'] += 1
            elif att <= 85:
                att_bands['average_75_85'] += 1
            else:
                att_bands['good_gt_85'] += 1

            if cgpa >= 9.0:
                cgpa_bands['gt_9'] += 1
            elif cgpa >= 8.0:
                cgpa_bands['between_8_9'] += 1
            elif cgpa >= 7.0:
                cgpa_bands['between_7_8'] += 1
            else:
                cgpa_bands['lt_7'] += 1

        avg_att = round(total_att_sum / total_students, 1)
        avg_ps = round(total_placement_score / total_students, 1)

        return Response({
            'department': dept,
            'total_students': total_students,
            'average_attendance': avg_att,
            'attendance_bands': att_bands,
            'cgpa_bands': cgpa_bands,
            'total_arrears': total_arrears,
            'average_placement_score': avg_ps
        }, status=status.HTTP_200_OK)


class ExportStudentsCsvView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        faculty_email = request.query_params.get('faculty_email')
        dept = request.query_params.get('dept')

        qs = get_faculty_accessible_students(faculty_email, dept=dept)

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="sars_students_report.csv"'

        writer = csv.writer(response)
        writer.writerow([
            'Student ID', 'Register No', 'Name', 'Department', 'Year', 'Section',
            'Email', 'Phone', 'Parent Name', 'Parent Phone', 'CGPA', 'Attendance %',
            'Arrears Count', 'Placement Score', '10th %', '12th Cutoff'
        ])

        for s in qs:
            m = calculate_student_academic_metrics(s)
            writer.writerow([
                s.student_id, s.reg_no, s.name, s.department, s.year, s.section,
                s.email, s.phone, s.parent_name or s.father_name, s.parent_phone or s.father_phone,
                m['cgpa'], m['attendance_pct'], m['arrears_count'], m['placement_score'],
                s.tenth_pct, s.twelfth_cutoff
            ])

        return response


class AcademicSummaryReportView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        metrics = calculate_student_academic_metrics(student)
        marks_qs = SubjectMark.objects.filter(student=student).select_related('subject').order_by('semester', 'subject__code')

        semester_breakdown = {}
        for m in marks_qs:
            sem = m.semester
            if sem not in semester_breakdown:
                semester_breakdown[sem] = []
            semester_breakdown[sem].append({
                'code': m.subject.code,
                'name': m.subject.name,
                'credits': m.subject.credits,
                'i1': m.i1,
                'i2': m.i2,
                'i3': m.i3,
                'model': m.model_exam,
                'grade': m.grade,
                'grade_point': m.grade_point
            })

        return Response({
            'student_id': student.student_id,
            'reg_no': student.reg_no,
            'name': student.name,
            'department': student.department,
            'year': student.year,
            'section': student.section,
            'email': student.email,
            'phone': student.phone,
            'metrics': metrics,
            'semesters': semester_breakdown
        }, status=status.HTTP_200_OK)
