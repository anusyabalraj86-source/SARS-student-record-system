from django.contrib import admin
# faculty_portal views are analytics and aggregate views over other models.
