from django.db import models

class Notification(models.Model):
    title = models.CharField(max_length=255)
    body = models.TextField()
    date = models.DateField()
    posted_by = models.CharField(max_length=150)
    department = models.CharField(max_length=50, default='ALL')
    target_role = models.CharField(max_length=30, default='ALL')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-id']

    def __str__(self):
        return f"{self.title} ({self.date})"


class NotificationReply(models.Model):
    notification = models.ForeignKey(Notification, on_delete=models.CASCADE, related_name='replies')
    sender_name = models.CharField(max_length=150)
    sender_role = models.CharField(max_length=30, default='student')
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender_name} on #{self.notification_id}: {self.message[:30]}"


class DirectMessage(models.Model):
    sender_email = models.CharField(max_length=150)
    sender_name = models.CharField(max_length=150)
    sender_role = models.CharField(max_length=30, default='student')  # 'student' | 'faculty'
    receiver_email = models.CharField(max_length=150)
    receiver_name = models.CharField(max_length=150, blank=True)
    subject = models.CharField(max_length=255, blank=True)
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"From {self.sender_name} to {self.receiver_email}: {self.subject or self.message[:25]}"
