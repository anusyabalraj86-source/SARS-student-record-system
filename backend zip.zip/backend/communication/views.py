from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from datetime import datetime

from .models import Notification, NotificationReply, DirectMessage
from .serializers import NotificationSerializer, NotificationReplySerializer, DirectMessageSerializer

class NotificationListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        dept = request.query_params.get('dept')
        qs = Notification.objects.all().prefetch_related('replies')
        if dept and dept != 'ALL':
            qs = qs.filter(models.Q(department__iexact=dept) | models.Q(department='ALL'))

        serializer = NotificationSerializer(qs, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        title = request.data.get('title')
        body = request.data.get('body')
        by = request.data.get('by') or request.data.get('posted_by', 'Administration')
        dept = request.data.get('dept') or request.data.get('department', 'ALL')
        target_role = request.data.get('target_role', 'ALL')
        date_str = request.data.get('date', datetime.now().strftime('%Y-%m-%d'))

        if not title or not body:
            return Response({'error': 'Title and body are required.'}, status=status.HTTP_400_BAD_REQUEST)

        notice = Notification.objects.create(
            title=title,
            body=body,
            date=date_str,
            posted_by=by,
            department=dept,
            target_role=target_role
        )
        return Response({'success': True, 'notice': NotificationSerializer(notice).data}, status=status.HTTP_201_CREATED)


class NotificationReplyView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, notice_id):
        try:
            notice = Notification.objects.get(pk=notice_id)
        except Notification.DoesNotExist:
            return Response({'error': 'Notice not found.'}, status=status.HTTP_404_NOT_FOUND)

        sender_name = request.data.get('sender_name', 'Student')
        sender_role = request.data.get('sender_role', 'student')
        msg = request.data.get('message', '').strip()

        if not msg:
            return Response({'error': 'Message cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)

        reply = NotificationReply.objects.create(
            notification=notice,
            sender_name=sender_name,
            sender_role=sender_role,
            message=msg
        )
        return Response({'success': True, 'reply': NotificationReplySerializer(reply).data}, status=status.HTTP_201_CREATED)


class DirectMessageListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        email = request.query_params.get('email')
        if not email:
            return Response({'error': 'Email parameter is required.'}, status=status.HTTP_400_BAD_REQUEST)

        # Messages sent to or by this email
        from django.db.models import Q
        messages = DirectMessage.objects.filter(
            Q(sender_email__iexact=email) | Q(receiver_email__iexact=email)
        )
        serializer = DirectMessageSerializer(messages, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        sender_email = request.data.get('sender_email')
        sender_name = request.data.get('sender_name')
        sender_role = request.data.get('sender_role', 'student')
        receiver_email = request.data.get('receiver_email')
        receiver_name = request.data.get('receiver_name', '')
        subject = request.data.get('subject', '')
        message = request.data.get('message', '').strip()

        if not sender_email or not receiver_email or not message:
            return Response({'error': 'sender_email, receiver_email, and message are required.'}, status=status.HTTP_400_BAD_REQUEST)

        msg_obj = DirectMessage.objects.create(
            sender_email=sender_email,
            sender_name=sender_name or sender_email,
            sender_role=sender_role,
            receiver_email=receiver_email,
            receiver_name=receiver_name,
            subject=subject,
            message=message
        )
        return Response({'success': True, 'message': DirectMessageSerializer(msg_obj).data}, status=status.HTTP_201_CREATED)


class DirectMessageReadView(APIView):
    permission_classes = [AllowAny]

    def patch(self, request, pk):
        try:
            msg = DirectMessage.objects.get(pk=pk)
            msg.is_read = True
            msg.save()
            return Response({'success': True, 'message_id': msg.id, 'is_read': True})
        except DirectMessage.DoesNotExist:
            return Response({'error': 'Message not found.'}, status=status.HTTP_404_NOT_FOUND)
