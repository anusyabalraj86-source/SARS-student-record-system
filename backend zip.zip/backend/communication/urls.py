from django.urls import path
from .views import (
    NotificationListView,
    NotificationReplyView,
    DirectMessageListView,
    DirectMessageReadView
)

urlpatterns = [
    # Notifications
    path('notifications/', NotificationListView.as_view(), name='notifications-list-create'),
    path('notifications/<int:notice_id>/reply/', NotificationReplyView.as_view(), name='notification-reply'),

    # Direct messaging / doubts
    path('communication/messages/', DirectMessageListView.as_view(), name='direct-messages'),
    path('communication/messages/<int:pk>/read/', DirectMessageReadView.as_view(), name='direct-message-read'),
]
