from rest_framework import serializers
from .models import Notification, NotificationReply, DirectMessage

class NotificationReplySerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationReply
        fields = '__all__'


class NotificationSerializer(serializers.ModelSerializer):
    replies = NotificationReplySerializer(many=True, read_only=True)
    by = serializers.CharField(source='posted_by', read_only=True)

    class Meta:
        model = Notification
        fields = ['id', 'title', 'body', 'date', 'by', 'posted_by', 'department', 'target_role', 'replies', 'created_at']


class DirectMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = DirectMessage
        fields = '__all__'
