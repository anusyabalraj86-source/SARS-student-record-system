from django.contrib import admin
from .models import Notification, NotificationReply, DirectMessage

class NotificationReplyInline(admin.TabularInline):
    model = NotificationReply
    extra = 0

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'posted_by', 'department', 'target_role')
    search_fields = ('title', 'body', 'posted_by')
    list_filter = ('department', 'target_role', 'date')
    inlines = [NotificationReplyInline]


@admin.register(DirectMessage)
class DirectMessageAdmin(admin.ModelAdmin):
    list_display = ('sender_name', 'sender_email', 'receiver_email', 'subject', 'is_read', 'created_at')
    search_fields = ('sender_name', 'sender_email', 'receiver_email', 'subject', 'message')
    list_filter = ('is_read', 'created_at')
