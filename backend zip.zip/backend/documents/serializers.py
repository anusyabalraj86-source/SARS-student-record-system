from rest_framework import serializers
from .models import StudentDocument

class StudentDocumentSerializer(serializers.ModelSerializer):
    file_url = serializers.SerializerMethodField()
    student_name = serializers.CharField(source='student.name', read_only=True)
    reg_no = serializers.CharField(source='student.reg_no', read_only=True)

    class Meta:
        model = StudentDocument
        fields = ['id', 'student', 'student_name', 'reg_no', 'doc_type', 'title', 'file', 'file_url', 'is_verified', 'verified_by', 'uploaded_at']

    def get_file_url(self, obj):
        if obj.file:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.file.url)
            return obj.file.url
        return ''
