from django.contrib import admin
from .models import StudentDocument

@admin.register(StudentDocument)
class StudentDocumentAdmin(admin.ModelAdmin):
    list_display = ('student', 'title', 'doc_type', 'is_verified', 'verified_by', 'uploaded_at')
    search_fields = ('student__name', 'student__reg_no', 'title')
    list_filter = ('doc_type', 'is_verified', 'uploaded_at')
