from django.urls import path
from .views import DocumentUploadView, DocumentVerifyView

urlpatterns = [
    path('documents/upload/', DocumentUploadView.as_view(), name='document-upload'),
    path('documents/my-documents/', DocumentUploadView.as_view(), name='my-documents'),
    path('documents/<int:pk>/verify/', DocumentVerifyView.as_view(), name='document-verify'),
]
