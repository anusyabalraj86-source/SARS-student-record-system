from django.db import models
from accounts.models import StudentProfile

class StudentDocument(models.Model):
    DOC_TYPES = [
        ('10th_marksheet', '10th Marksheet'),
        ('12th_marksheet', '12th Marksheet'),
        ('community_certificate', 'Community Certificate'),
        ('income_certificate', 'Income Certificate'),
        ('aadhar_card', 'Aadhar Card'),
        ('apaar_id', 'APAAR Card'),
        ('resume', 'Resume / CV'),
        ('other', 'Other Certificate / Record'),
    ]

    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='documents')
    doc_type = models.CharField(max_length=50, choices=DOC_TYPES, default='other')
    title = models.CharField(max_length=150)
    file = models.FileField(upload_to='documents/')
    is_verified = models.BooleanField(default=False)
    verified_by = models.CharField(max_length=150, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"{self.student.name} - {self.get_doc_type_display()} ({self.title})"
