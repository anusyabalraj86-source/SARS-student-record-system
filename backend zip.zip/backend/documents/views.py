from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.parsers import MultiPartParser, FormParser

from accounts.models import StudentProfile
from .models import StudentDocument
from .serializers import StudentDocumentSerializer

class DocumentUploadView(APIView):
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        docs = StudentDocument.objects.filter(student=student)
        return Response(StudentDocumentSerializer(docs, many=True, context={'request': request}).data, status=status.HTTP_200_OK)

    def post(self, request):
        student_id = request.data.get('student_id')
        reg_no = request.data.get('reg_no')
        doc_type = request.data.get('doc_type', 'other')
        title = request.data.get('title', '')
        file = request.FILES.get('file')

        if not file:
            return Response({'error': 'File is required.'}, status=status.HTTP_400_BAD_REQUEST)

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        if not title:
            title = file.name

        doc = StudentDocument.objects.create(
            student=student,
            doc_type=doc_type,
            title=title,
            file=file
        )

        return Response({
            'success': True,
            'document': StudentDocumentSerializer(doc, context={'request': request}).data
        }, status=status.HTTP_201_CREATED)


class DocumentVerifyView(APIView):
    permission_classes = [AllowAny]

    def patch(self, request, pk):
        try:
            doc = StudentDocument.objects.get(pk=pk)
            doc.is_verified = True
            doc.verified_by = request.data.get('verified_by', 'Faculty Advisor')
            doc.save()
            return Response({'success': True, 'document_id': doc.id, 'is_verified': True})
        except StudentDocument.DoesNotExist:
            return Response({'error': 'Document not found.'}, status=status.HTTP_404_NOT_FOUND)
