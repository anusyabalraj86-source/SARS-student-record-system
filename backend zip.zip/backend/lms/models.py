from django.db import models
from accounts.models import StudentProfile

class LMSCourse(models.Model):
    code = models.CharField(max_length=30, unique=True)
    title = models.CharField(max_length=150)
    department = models.CharField(max_length=50, default='CSE')
    faculty_name = models.CharField(max_length=150)
    semester = models.IntegerField(default=1)
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.code} - {self.title} ({self.faculty_name})"


class LearningMaterial(models.Model):
    MATERIAL_TYPES = [
        ('pdf', 'PDF Document'),
        ('ppt', 'Presentation Slides'),
        ('book', 'Reference Book'),
        ('assign', 'Assignment Sheet'),
        ('video', 'Video Lecture / Link'),
    ]

    course = models.ForeignKey(LMSCourse, on_delete=models.CASCADE, related_name='materials')
    material_type = models.CharField(max_length=20, choices=MATERIAL_TYPES, default='pdf')
    name = models.CharField(max_length=255)
    file = models.FileField(upload_to='materials/', blank=True, null=True)
    external_url = models.URLField(blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"[{self.material_type}] {self.name} - {self.course.code}"


class Homework(models.Model):
    course_code = models.CharField(max_length=30)
    course_title = models.CharField(max_length=150, blank=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    due_date = models.DateField()
    department = models.CharField(max_length=50, default='CSE')
    section = models.CharField(max_length=10, blank=True, default='A')
    posted_by = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-due_date']

    def __str__(self):
        return f"{self.course_code}: {self.title} (Due: {self.due_date})"


class HomeworkSubmission(models.Model):
    homework = models.ForeignKey(Homework, on_delete=models.CASCADE, related_name='submissions')
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name='homework_submissions')
    is_done = models.BooleanField(default=False)
    submission_file = models.FileField(upload_to='homework_submissions/', blank=True, null=True)
    submission_notes = models.TextField(blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('homework', 'student')

    def __str__(self):
        return f"{self.student.name} - {self.homework.title} [Done: {self.is_done}]"


class HomeworkMessage(models.Model):
    homework = models.ForeignKey(Homework, on_delete=models.CASCADE, related_name='messages')
    sender_name = models.CharField(max_length=150)
    sender_role = models.CharField(max_length=30, default='student')
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender_name}: {self.message[:30]}"
