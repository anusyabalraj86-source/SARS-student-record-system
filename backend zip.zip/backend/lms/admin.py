from django.contrib import admin
from .models import LMSCourse, LearningMaterial, Homework, HomeworkSubmission, HomeworkMessage

class LearningMaterialInline(admin.TabularInline):
    model = LearningMaterial
    extra = 1

@admin.register(LMSCourse)
class LMSCourseAdmin(admin.ModelAdmin):
    list_display = ('code', 'title', 'department', 'faculty_name', 'semester')
    search_fields = ('code', 'title', 'faculty_name')
    list_filter = ('department', 'semester')
    inlines = [LearningMaterialInline]


@admin.register(LearningMaterial)
class LearningMaterialAdmin(admin.ModelAdmin):
    list_display = ('name', 'course', 'material_type', 'uploaded_at')
    list_filter = ('material_type', 'course')
    search_fields = ('name', 'course__code', 'course__title')


class HomeworkSubmissionInline(admin.TabularInline):
    model = HomeworkSubmission
    extra = 0

class HomeworkMessageInline(admin.TabularInline):
    model = HomeworkMessage
    extra = 0

@admin.register(Homework)
class HomeworkAdmin(admin.ModelAdmin):
    list_display = ('course_code', 'title', 'due_date', 'posted_by', 'department', 'section')
    search_fields = ('course_code', 'title', 'posted_by')
    list_filter = ('department', 'section', 'due_date')
    inlines = [HomeworkSubmissionInline, HomeworkMessageInline]


@admin.register(HomeworkSubmission)
class HomeworkSubmissionAdmin(admin.ModelAdmin):
    list_display = ('student', 'homework', 'is_done', 'updated_at')
    list_filter = ('is_done',)
