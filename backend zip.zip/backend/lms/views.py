from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser

from accounts.models import StudentProfile
from .models import LMSCourse, LearningMaterial, Homework, HomeworkSubmission, HomeworkMessage
from .serializers import LMSCourseSerializer, LearningMaterialSerializer, HomeworkSerializer, HomeworkMessageSerializer

class LMSCourseListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        dept = request.query_params.get('dept') or request.query_params.get('department')
        sem = request.query_params.get('sem') or request.query_params.get('semester')

        qs = LMSCourse.objects.all().prefetch_related('materials')
        if dept:
            qs = qs.filter(department__iexact=dept)
        if sem:
            qs = qs.filter(semester=sem)

        serializer = LMSCourseSerializer(qs, many=True, context={'request': request})
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        code = request.data.get('code')
        title = request.data.get('title')
        dept = request.data.get('dept') or request.data.get('department', 'CSE')
        faculty = request.data.get('faculty') or request.data.get('faculty_name', 'Faculty')
        sem = request.data.get('semester', 1)
        desc = request.data.get('desc') or request.data.get('description', '')

        if not code or not title:
            return Response({'error': 'Code and Title are required.'}, status=status.HTTP_400_BAD_REQUEST)

        course, created = LMSCourse.objects.update_or_create(
            code=code,
            defaults={
                'title': title,
                'department': dept,
                'faculty_name': faculty,
                'semester': int(sem),
                'description': desc
            }
        )
        return Response(LMSCourseSerializer(course, context={'request': request}).data, status=status.HTTP_201_CREATED)


class LMSMaterialUploadView(APIView):
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def get(self, request):
        course_id = request.query_params.get('course_id')
        course_code = request.query_params.get('course_code')

        qs = LearningMaterial.objects.all()
        if course_id:
            qs = qs.filter(course_id=course_id)
        if course_code:
            qs = qs.filter(course__code__iexact=course_code)

        serializer = LearningMaterialSerializer(qs, many=True, context={'request': request})
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        course_code = request.data.get('course_code')
        course_id = request.data.get('course_id')
        name = request.data.get('name')
        mat_type = request.data.get('type') or request.data.get('material_type', 'pdf')
        file = request.FILES.get('file')
        external_url = request.data.get('external_url', '')

        course = None
        if course_id:
            course = LMSCourse.objects.filter(pk=course_id).first()
        elif course_code:
            course = LMSCourse.objects.filter(code__iexact=course_code).first()

        if not course:
            return Response({'error': 'Course not found.'}, status=status.HTTP_404_NOT_FOUND)

        if not name:
            name = file.name if file else 'Material'

        mat = LearningMaterial.objects.create(
            course=course,
            name=name,
            material_type=mat_type,
            file=file,
            external_url=external_url
        )
        return Response({
            'success': True,
            'material': LearningMaterialSerializer(mat, context={'request': request}).data
        }, status=status.HTTP_201_CREATED)


class HomeworkListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        student_id = request.query_params.get('student_id')
        reg_no = request.query_params.get('reg_no')
        dept = request.query_params.get('dept')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        qs = Homework.objects.all().prefetch_related('messages')
        if dept:
            qs = qs.filter(department__iexact=dept)
        elif student:
            qs = qs.filter(department__iexact=student.department)

        serializer = HomeworkSerializer(qs, many=True, context={'student': student})
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        course_code = request.data.get('course') or request.data.get('course_code')
        title = request.data.get('title')
        desc = request.data.get('desc') or request.data.get('description')
        due = request.data.get('due') or request.data.get('due_date')
        by = request.data.get('by') or request.data.get('posted_by', 'Faculty')
        dept = request.data.get('dept', 'CSE')
        sec = request.data.get('section', 'A')

        if not course_code or not title or not due:
            return Response({'error': 'course, title, and due date are required.'}, status=status.HTTP_400_BAD_REQUEST)

        hw = Homework.objects.create(
            course_code=course_code,
            title=title,
            description=desc or '',
            due_date=due,
            posted_by=by,
            department=dept,
            section=sec
        )
        return Response({
            'success': True,
            'homework': HomeworkSerializer(hw).data
        }, status=status.HTTP_201_CREATED)


class HomeworkToggleView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, hw_id):
        student_id = request.data.get('student_id')
        reg_no = request.data.get('reg_no')

        student = None
        if student_id:
            student = StudentProfile.objects.filter(student_id__iexact=student_id).first()
        elif reg_no:
            student = StudentProfile.objects.filter(reg_no__iexact=reg_no).first()
        else:
            student = StudentProfile.objects.first()

        if not student:
            return Response({'error': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        try:
            hw = Homework.objects.get(pk=hw_id)
        except Homework.DoesNotExist:
            return Response({'error': 'Homework not found.'}, status=status.HTTP_404_NOT_FOUND)

        sub, created = HomeworkSubmission.objects.get_or_create(
            homework=hw,
            student=student,
            defaults={'is_done': True}
        )
        if not created:
            sub.is_done = not sub.is_done
            sub.save()

        return Response({
            'success': True,
            'homework_id': hw.id,
            'is_done': sub.is_done
        }, status=status.HTTP_200_OK)


class HomeworkMessageView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, hw_id):
        try:
            hw = Homework.objects.get(pk=hw_id)
        except Homework.DoesNotExist:
            return Response({'error': 'Homework not found.'}, status=status.HTTP_404_NOT_FOUND)

        sender_name = request.data.get('sender_name', 'Student')
        sender_role = request.data.get('sender_role', 'student')
        msg = request.data.get('message', '').strip()

        if not msg:
            return Response({'error': 'Message cannot be empty.'}, status=status.HTTP_400_BAD_REQUEST)

        message_obj = HomeworkMessage.objects.create(
            homework=hw,
            sender_name=sender_name,
            sender_role=sender_role,
            message=msg
        )
        return Response({
            'success': True,
            'message': HomeworkMessageSerializer(message_obj).data
        }, status=status.HTTP_201_CREATED)
