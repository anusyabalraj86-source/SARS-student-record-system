from django.urls import path
from .views import (
    LMSCourseListView,
    LMSMaterialUploadView,
    HomeworkListView,
    HomeworkToggleView,
    HomeworkMessageView
)

urlpatterns = [
    # LMS Courses & Materials
    path('lms/courses/', LMSCourseListView.as_view(), name='lms-courses'),
    path('lms/materials/', LMSMaterialUploadView.as_view(), name='lms-materials'),
    path('lms/materials/upload/', LMSMaterialUploadView.as_view(), name='upload-lms-material'),

    # Homework
    path('homework/student/', HomeworkListView.as_view(), name='homework-student'),
    path('homework/create/', HomeworkListView.as_view(), name='homework-create'),
    path('homework/<int:hw_id>/toggle/', HomeworkToggleView.as_view(), name='homework-toggle'),
    path('homework/<int:hw_id>/message/', HomeworkMessageView.as_view(), name='homework-message'),
]
