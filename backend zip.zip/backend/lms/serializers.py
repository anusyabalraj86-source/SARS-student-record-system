from rest_framework import serializers
from .models import LMSCourse, LearningMaterial, Homework, HomeworkSubmission, HomeworkMessage

class LearningMaterialSerializer(serializers.ModelSerializer):
    file_url = serializers.SerializerMethodField()

    class Meta:
        model = LearningMaterial
        fields = ['id', 'course', 'material_type', 'type', 'name', 'file', 'file_url', 'external_url', 'uploaded_at']

    type = serializers.CharField(source='material_type', read_only=True)

    def get_file_url(self, obj):
        if obj.file:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.file.url)
            return obj.file.url
        return obj.external_url or ''


class LMSCourseSerializer(serializers.ModelSerializer):
    materials = LearningMaterialSerializer(many=True, read_only=True)
    faculty = serializers.CharField(source='faculty_name', read_only=True)

    class Meta:
        model = LMSCourse
        fields = ['id', 'code', 'title', 'faculty', 'faculty_name', 'department', 'semester', 'description', 'materials']


class HomeworkMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = HomeworkMessage
        fields = '__all__'


class HomeworkSerializer(serializers.ModelSerializer):
    messages = HomeworkMessageSerializer(many=True, read_only=True)
    course = serializers.CharField(source='course_code', read_only=True)
    by = serializers.CharField(source='posted_by', read_only=True)
    due = serializers.DateField(source='due_date', read_only=True)
    desc = serializers.CharField(source='description', read_only=True)
    is_done = serializers.SerializerMethodField()

    class Meta:
        model = Homework
        fields = [
            'id', 'course', 'course_code', 'course_title', 'title',
            'desc', 'description', 'due', 'due_date', 'by', 'posted_by',
            'department', 'section', 'messages', 'is_done', 'created_at'
        ]

    def get_is_done(self, obj):
        student = self.context.get('student')
        if student:
            sub = HomeworkSubmission.objects.filter(homework=obj, student=student).first()
            return sub.is_done if sub else False
        return False
