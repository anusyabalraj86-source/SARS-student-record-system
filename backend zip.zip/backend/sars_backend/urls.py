"""
URL configuration for sars_backend project.
Student Activity Record System (SARS)
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.http import JsonResponse

def api_root_overview(request):
    return JsonResponse({
        'system': 'SARS - Student Activity Record System Backend API',
        'status': 'online',
        'version': '1.0.0',
        'framework': 'Django 6.1 + Django REST Framework',
        'database': 'SQLite',
        'documentation': 'All endpoints accept and return JSON. CORS is enabled for frontend JavaScript fetch().',
        'endpoints': {
            'admin_panel': '/admin/',
            'auth': {
                'student_registration': '/api/auth/register/',
                'student_login': '/api/auth/login/student/',
                'faculty_login': '/api/auth/login/faculty/',
                'change_password': '/api/auth/change-password/',
            },
            'profile': {
                'student_profile': '/api/profile/student/',
                'upload_photo': '/api/profile/student/photo/',
            },
            'attendance': {
                'student_attendance': '/api/attendance/student/',
                'mark_attendance': '/api/attendance/mark/',
                'parent_alerts': '/api/attendance/parent-alerts/',
                'send_parent_alert': '/api/attendance/parent-alert/send/',
            },
            'academics_and_marks': {
                'student_marks': '/api/marks/student/',
                'save_marks': '/api/marks/save/',
                'subjects_list': '/api/marks/subjects/',
                'sgpa_cgpa': '/api/academics/sgpa-cgpa/',
                'daily_class_log': '/api/academics/daily-log/',
            },
            'lms': {
                'courses': '/api/lms/courses/',
                'materials': '/api/lms/materials/',
                'upload_material': '/api/lms/materials/upload/',
                'homework_student': '/api/homework/student/',
                'homework_create': '/api/homework/create/',
                'homework_toggle': '/api/homework/<id>/toggle/',
                'homework_message': '/api/homework/<id>/message/',
            },
            'activities_and_portfolio': {
                'student_activities_overview': '/api/activities/student/',
                'class_activity_log': '/api/activities/class-log/',
                'faculty_assignments': '/api/activities/faculty/assignments/',
                'toggle_faculty_activity': '/api/activities/assignments/<id>/toggle/',
                'internships': '/api/activities/internships/',
                'sports': '/api/activities/sports/',
                'cultural': '/api/activities/cultural/',
                'hackathons': '/api/activities/hackathons/',
                'workshops': '/api/activities/workshops/',
                'papers': '/api/activities/papers/',
                'portfolio_skills': '/api/portfolio/skills/',
                'portfolio_projects': '/api/portfolio/projects/',
                'portfolio_certifications': '/api/portfolio/certifications/',
            },
            'notifications_and_communication': {
                'notifications': '/api/notifications/',
                'direct_messages': '/api/communication/messages/',
            },
            'documents': {
                'upload_document': '/api/documents/upload/',
                'my_documents': '/api/documents/my-documents/',
            },
            'faculty_portal_and_analytics': {
                'faculty_student_records': '/api/faculty/students/',
                'faculty_student_detail': '/api/faculty/students/<student_id>/',
                'faculty_analytics': '/api/faculty/analytics/',
                'academic_summary_report': '/api/reports/academic-summary/',
                'export_students_csv': '/api/reports/export/students-csv/',
            }
        }
    })

urlpatterns = [
    # Admin Panel
    path('admin/', admin.site.urls),

    # API Root Overview
    path('', api_root_overview, name='api-root-overview'),
    path('api/', api_root_overview, name='api-overview'),

    # Modular SARS App API Routes
    path('api/', include('accounts.urls')),
    path('api/', include('academics.urls')),
    path('api/', include('attendance.urls')),
    path('api/', include('lms.urls')),
    path('api/', include('activities.urls')),
    path('api/', include('communication.urls')),
    path('api/', include('documents.urls')),
    path('api/', include('faculty_portal.urls')),
]

# Media and Static support in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
